'use strict';
// =============================================================================================
// Brick Strike 3.4: сервер сетевой игры (командный бой с ботами, закладка бомбы, рейтинг 2×2, пати, кланы, гранаты).
// Нужен только Node.js 14 или новее, сторонних пакетов нет.
//
//   Запуск:   node server.js
//   Порт:     переменная PORT (по умолчанию 3100)
//   Проверка: открой в браузере  http://АДРЕС_СЕРВЕРА:3100/
//
// Сервер ведёт комнаты, здоровье, счёт, раунды с бомбой и рейтинг. Каждый игрок сам двигает своего
// бойца и сам сообщает о попаданиях, а сервер считает урон по своей таблице оружия и не даёт
// стрелять быстрее, чем может ствол. Оружие поделено по сторонам, как в CS: урон из чужого ствола
// (АК-47 у спецназа, M4 у террористов) сервер не засчитывает. Рейтинг меняется только в матчах
// «Рейтинг 2×2» между живыми игроками и лежит в файле ratings.json рядом с сервером.
//
// С версии 3.4:
//   Гранаты: осколочная, световая, дымовая, Молотов и зажигательная. В раундах с бомбой их покупают (не больше четырёх), в командном
//   бою каждая жизнь даёт осколочную и световую. Урон от осколочной и от огня считает сервер. Новая карта «Оазис» (две точки, A и B);
//   общие комнаты открываются то на ней, то на «Старом городе». Админ-метку и перчатки сервер даёт только по настоящему админ-ключу
//   (раньше хватало числа, которое можно было подсмотреть). Игры до 3.4 сервер не пускает, игра 3.4 не заходит на старый сервер.
//
// С версии 3.3:
//   Кланы (clans.json): тег клана виден в таблице боя. Пинг каждого игрока раз в две секунды уходит всем в комнате.
//   Рейтинг 2×2: победа от +17 до +42, поражение от −10 до −30 по игре бойца, MVP получает больше. Карта «Старый город»
//   изменилась (дома, через которые можно пройти), поэтому игры до 3.3 сервер не пускает, а игра 3.3 не заходит на старый сервер.
//
// С версии 3.2:
//   Для карточки «Онлайн» в меню сервер сообщает, сколько людей в каждом режиме, сколько ещё ищут соперника, сколько
//   боёв идёт и рекорд онлайна за сутки. В раундах с деньгами выбросить и обменять при подборе можно только своё оружие.
//
// С версии 3.1:
//   Раунды с бомбой как в CS: деньги ведёт сервер. Первый раунд каждой половины пистолетный ($800 и пистолет своей
//   стороны), деньги за победу, поражение (больше за серию поражений), закладку, разминирование и убийства, закупка
//   в начале раунда через сервер, выжившие оставляют оружие. Урон засчитывается только из своего ствола: купленного,
//   выданного или подобранного. Игры до 3.1 этого не умеют: в раунды с бомбой и в рейтинг их не пускают (им приходит
//   «обнови игру»), в командный бой они заходят как раньше.
//
// С версии 3.0:
//   Голда за донат. Владелец в игре создаёт разовые коды на голду и промокоды (например, раз в месяц), сервер
//   хранит их в файле codes.json рядом с рейтингом (переменная CODES меняет место) и следит, чтобы разовый код
//   сработал один раз, а промокод каждый игрок ввёл только однажды. Неверные коды: не больше 10 за 10 минут с адреса.
//
// С версии 2.6:
//   Боты. В командном бою сервер добирает каждую команду ботами (переменная BOTS, по умолчанию до 5
//   бойцов; 0 выключает), когда в комнате двое живых игроков или когда одиночка попросил начать бой.
//   Заходит человек: бот его команды уходит. Ботов ведёт игра одного из игроков («хозяин»): она
//   считает их движение и стрельбу и сообщает серверу, а здоровье, счёт и возрождение ботов ведёт
//   сервер, как у людей. Хозяин вышел или завис: ботов подхватывает игра другого игрока.
//   Пати. Игроки с общим кодом пати попадают в одну комнату и в одну команду.
//
// С версии 2.7:
//   Карта «Старый город» стала в полтора раза больше: точка A на новом месте, раунд с бомбой идёт 115 секунд.
//   Игра старше 2.7 на этот сервер не заходит (у неё другая карта), ей пишется, что нужно обновление.
//   Оружие на земле. У убитого выпадает ствол, который был в руках, вместе со скином. Сервер помнит, где он
//   лежит, и отдаёт его первому, кто попросил, стоя рядом; подобранный ствол чужой стороны наносит урон.
//   Своё оружие игрок может выбросить сам, чтобы его взял друг.
//   «Сейчас играют». Игра в меню получает список общих боёв, где есть люди, и может зайти в выбранный.
//   Перчатки админа. Их видно у других только тогда, когда игра владельца назвала серверу его ключ.
// =============================================================================================
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

function envInt(name, lo, hi, def) { const v = parseInt(process.env[name], 10); return isFinite(v) ? Math.max(lo, Math.min(hi, v)) : def; }
const PORT = envInt('PORT', 1, 65535, 3100);
const KILL_LIMIT = envInt('KILLS', 5, 500, 50);          // до скольки убийств идёт матч
const MATCH_MS = envInt('MINUTES', 2, 60, 10) * 60000;   // сколько минут длится матч
const ROOM_SIZE = envInt('ROOM_SIZE', 2, 16, 10);        // игроков в одной комнате
const MAX_ROOMS = 40, MAX_CONN = 200, MAX_FRAME = 2048;
const FAST = process.env.BS_TEST_FAST === '1' ? 0.1 : (parseFloat(process.env.BS_TEST_FAST) > 0 ? Math.min(1, parseFloat(process.env.BS_TEST_FAST)) : 1);      // только для проверок: раунды короче
const TICK_MS = 50, RESPAWN_MS = envInt('BS_TEST_RESPAWN', 500, 60000, 3000), PROTECT_MS = 2000, POST_MS = 12000, IDLE_MS = 15000;      // (возрождение через 3 секунды; переменная только для проверок)
const VERSION = 2;
const MIN_BUILD = 35;         // с какой сборки игры пускать: 35 это версия 3.5 (аккаунты, лобби, рынок); 34 была 3.4 (гранаты, «Оазис»); 33 была 3.3, где в «Старом городе» появились дома, через которые можно пройти (до неё 27: в 2.7 карта стала в полтора раза больше; у старой игры другая карта: стены не совпадут)
const MAP_VER = 4;            // (3.4: 4, «Оазис») какие карты знает сервер: игра не зайдёт на сервер, который не называет её число (3: карта 3.3)
const BOT_TEAM = envInt('BOTS', 0, 8, 5);                // до скольки бойцов боты добирают каждую команду в командном бою (0: без ботов)
const BOT_BUILD = 26;         // с какой сборки игра умеет вести ботов
const ECO_BUILD = 31;         // с какой сборки игра знает деньги в раундах с бомбой (3.1): старые игры ходят только в командный бой
const DROP_MS = 25000, DROP_ROUND_MS = 120000, DROP_MAX = 40;      // сколько лежит выпавшее оружие (в бою с возрождением; в раундах оно лежит до конца раунда) и сколько его может лежать в одной комнате
function dropLife(room) { return room.mode === 'bomb' ? DROP_ROUND_MS : DROP_MS; }
const BOT_DMG = 0.75;         // урон от ботов немного слабее
const HOST_LAG_MS = 3500;     // хозяин ботов молчит дольше: ботов берёт другой игрок
const BOT_NAMES = ['Барс', 'Беркут', 'Волк', 'Ворон', 'Гранит', 'Гром', 'Кедр', 'Кобра', 'Орёл', 'Рысь', 'Скиф', 'Сокол', 'Тайга', 'Тень', 'Шторм', 'Ястреб', 'Байкал', 'Буран', 'Вихрь', 'Зубр'];
// раунды с бомбой: до скольки побед, сколько длятся закладка, разминирование, фитиль, раунд, заморозка перед раундом
const NEED = envInt('ROUNDS', 2, 16, 5), PLANT_MS = 3200 * FAST, DEFUSE_MS = 6000 * FAST, FUSE_MS = 40000 * FAST, ROUND_MS = 115000 * FAST, FREEZE_MS = 6000 * FAST, ROUND_POST_MS = 5000 * FAST;
// взрыв бомбы (2.9): полная сила у бомбы, дальше плавно слабее. Ближе примерно 560 единиц не выживает никто (без брони около 650),
// ранит до края радиуса, стены не защищают. Игра считает так же
const BOMB_RADIUS = 1100, BOMB_POWER = 650, BOMB_SPREAD = 340;
function bombDamage(d) { return d >= BOMB_RADIUS ? 0 : BOMB_POWER * Math.exp(-d * d / (2 * BOMB_SPREAD * BOMB_SPREAD)); }
// где можно заложить бомбу: x от и до, z от и до. На «Старом городе» одна точка A; на «Оазисе» (3.4) две: A у дворца и B во дворе караван-сарая
const BOMB_ZONE = { town: [[-96, 1008, 384, 1440]], oasis: [[1152, 240, 1872, 750], [-1872, 0, -1200, 600]] };
// деньги в раундах с бомбой (3.1), как в CS и в игре без интернета. Первый раунд каждой половины пистолетный: у всех $800 и только
// пистолет своей стороны. За победу $3250, за поражение $1400 и на $500 больше за каждое следующее поражение подряд (до $3400),
// террористам ещё $800, если бомба стояла, а раунд проигран; за закладку и разминирование $300 тому, кто это сделал; за убийство
// награда ствола (ножом $1500). Выжившие оставляют оружие и броню, погибшие начинают с пистолетом. Покупают во время заморозки и
// первые 15 секунд раунда; деньги и то, что у кого есть, помнит сервер: стрелять можно только из своего (купленного или подобранного)
const MONEY = { start: 800, max: 16000, win: 3250, loss: 1400, step: 500, plant: 300, defuse: 300, planted: 800, knife: 1500 };
const BUY_MS = 15000 * FAST, HALF_FREEZE_MS = 3000 * FAST;          // (в первом раунде половины заморозка дольше: смена сторон и закупка)
const PRICE = { glock18: [200, 300], usp: [200, 300], p2000: [200, 300], p228: [300, 300], fiveseven: [500, 300], tec9: [500, 300], cz75: [500, 100],
  elite: [300, 300], deagle: [700, 300], mac10: [1050, 600], tmp: [1250, 600], mp7: [1500, 600], mp5: [1500, 600], ump45: [1200, 600], p90: [2350, 300],
  bizon: [1400, 600], m3: [1050, 900], xm1014: [2000, 900], sawedoff: [1100, 900], mag7: [1300, 900], galil: [1800, 300], famas: [2050, 300],
  ak47: [2700, 300], m4a4: [3100, 300], m4a1: [2900, 300], sg552: [3000, 300], aug: [3300, 300], scout: [1700, 300], awp: [4750, 100],
  g3sg1: [5000, 300], sg550: [5000, 300], m249: [5200, 300], negev: [1700, 300] };      // цена и награда за убийство
const GEAR_PRICE = { vest: 650, vesthelm: 1000 };
// (3.4) гранаты: цена, сколько таких можно нести (всего не больше четырёх), чья сторона, что делает при взрыве
// (3.4) карты: «Старый город», awp_lego и «Оазис»; с бомбой играют на городе и на оазисе (там две точки)
const BOMB_MAPS = ['oasis', 'town'], ANY_MAPS = ['town', 'lego', 'oasis'], MAP_TURN_MS = 20 * 60000;
const NADE_IDS = ['he', 'flash', 'smoke', 'molotov', 'incgren'];
const NADE = { he: { price: 300, max: 1, kind: 'he' }, flash: { price: 200, max: 2, kind: 'flash' }, smoke: { price: 300, max: 1, kind: 'smoke' }, molotov: { price: 400, max: 1, kind: 'fire', side: 't' }, incgren: { price: 500, max: 1, kind: 'fire', side: 'ct' } };
const NADE_POPS = ['he', 'flash', 'smoke', 'fire', 'fizz'];
const NADE_MAX = 4, HE_R = 360, HE_DMG = 98, HE_AP = 0.57, FIRE_R = 140, FIRE_MS = 7000, FIRE_TICK = 250, FIRE_DMG = 8, SMOKE_R = 150, SMOKE_MS = 18000, NADE_REWARD = 300;
const PISTOLS = { glock18: 1, usp: 1, p2000: 1, p228: 1, fiveseven: 1, tec9: 1, cz75: 1, elite: 1, deagle: 1 };
const DEFAULT_PISTOL = { t: 'glock18', ct: 'usp' };         // с чем сторона начинает половину и с чем выходит погибший в прошлом раунде
const RATE_FILE = process.env.RATINGS || path.join(__dirname, 'ratings.json');
const UID_RE = /^[a-z0-9]{16,32}$/;

// оружие: [урон, доля урона на каждые 500 единиц пути, доля сквозь броню, пауза между выстрелами в мс, дробин]
const WEAPONS = {
  glock18: [30, 0.85, 0.47, 150, 1],
  usp: [35, 0.91, 0.505, 170, 1],
  p2000: [35, 0.91, 0.505, 170, 1],
  p228: [38, 0.9, 0.64, 150, 1],
  fiveseven: [32, 0.81, 0.91, 150, 1],
  tec9: [33, 0.79, 0.906, 120, 1],
  cz75: [31, 0.85, 0.776, 100, 1],
  elite: [38, 0.79, 0.575, 120, 1],
  deagle: [53, 0.93, 0.932, 225, 1],
  mac10: [29, 0.8, 0.575, 75, 1],
  tmp: [26, 0.87, 0.6, 70, 1],
  mp7: [29, 0.85, 0.625, 80, 1],
  mp5: [27, 0.85, 0.625, 80, 1],
  ump45: [35, 0.75, 0.65, 90, 1],
  p90: [26, 0.86, 0.69, 70, 1],
  bizon: [27, 0.8, 0.575, 80, 1],
  m3: [26, 0.7, 0.5, 882, 9],
  xm1014: [20, 0.7, 0.8, 351, 6],
  sawedoff: [32, 0.45, 0.75, 845, 8],
  mag7: [30, 0.45, 0.75, 845, 8],
  galil: [30, 0.98, 0.775, 90, 1],
  famas: [30, 0.96, 0.7, 90, 1],
  ak47: [36, 0.98, 0.775, 100, 1],
  m4a4: [33, 0.97, 0.7, 90, 1],
  m4a1: [38, 0.99, 0.7, 100, 1],
  sg552: [30, 0.98, 1, 110, 1],
  aug: [28, 0.98, 0.9, 100, 1],
  scout: [88, 0.98, 0.85, 1250, 1],
  awp: [115, 0.99, 0.975, 1463, 1],
  g3sg1: [80, 0.98, 0.825, 250, 1],
  sg550: [80, 0.98, 0.825, 250, 1],
  m249: [32, 0.97, 0.8, 80, 1],
  negev: [35, 0.97, 0.75, 75, 1]
};
// оружие одной стороны: остальное из таблицы выше есть у обеих
const SIDE = { glock18: 't', tec9: 't', mac10: 't', sawedoff: 't', galil: 't', ak47: 't', sg552: 't', g3sg1: 't',
  usp: 'ct', p2000: 'ct', fiveseven: 'ct', tmp: 'ct', mag7: 'ct', famas: 'ct', m4a4: 'ct', m4a1: 'ct', aug: 'ct', sg550: 'ct' };
const W_IDS = Object.keys(WEAPONS);                     // оружие по номеру: в том же порядке его знает игра
const KNIFE_DMG = [40, 90, 65, 180];                    // взмах, взмах в спину, укол, укол в спину
const KNIFE_AP = 0.6;
const HIT_MULT = [1, 4, 1, 1.25, 0.75];                 // 1 голова, 2 грудь, 3 живот, 4 ноги

const rooms = new Map();
const conns = new Set();

function log() { const a = Array.prototype.slice.call(arguments); a.unshift(new Date().toISOString().slice(0, 19).replace('T', ' ')); console.log.apply(console, a); }
function num(v, lo, hi, def) { return typeof v === 'number' && isFinite(v) ? Math.max(lo, Math.min(hi, v)) : def; }
function cleanName(v) { const s = String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f<>&"'`\\]/g, '').replace(/\s+/g, ' ').trim().slice(0, 14); return s || 'Игрок'; }
function cleanChat(v) { return String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80); }
function cleanRoom(v) { const s = String(v == null ? '' : v).toLowerCase().replace(/[^a-z0-9а-яё_-]/g, '').slice(0, 16); return s || 'public'; }

// ---- WebSocket: рукопожатие и кадры (RFC 6455), без сторонних пакетов -------------------------
function frame(text) {
  const data = Buffer.from(text, 'utf8'), n = data.length; let head;
  if (n < 126) head = Buffer.from([0x81, n]);
  else if (n < 65536) { head = Buffer.allocUnsafe(4); head[0] = 0x81; head[1] = 126; head.writeUInt16BE(n, 2); }
  else { head = Buffer.allocUnsafe(10); head[0] = 0x81; head[1] = 127; head.writeUInt32BE(0, 2); head.writeUInt32BE(n, 6); }
  return Buffer.concat([head, data]);
}
function sendRaw(c, buf) {
  if (c.dead) return;
  if (c.s.writableLength > 262144) { drop(c, 'slow'); return; }       // клиент не успевает читать
  try { c.s.write(buf); } catch (e) { drop(c, 'write'); }
}
function send(c, msg) { sendRaw(c, frame(JSON.stringify(msg))); }
function broadcast(room, msg, except) { const buf = frame(JSON.stringify(msg)); room.players.forEach(p => { if (p !== except && p.c) sendRaw(p.c, buf); }); if (room.watch) room.watch.forEach(c => sendRaw(c, buf)); }      // (3.6) и зрителям
function humans(room, team) { let n = 0; room.players.forEach(p => { if (!p.bot && (!team || p.team === team)) n++; }); return n; }

function drop(c, why) {
  if (c.dead) return; c.dead = true; conns.delete(c);
  try { c.s.destroy(); } catch (e) { /* уже закрыт */ }
  if (c.lb) { const L = lobbies.get(c.lb), q = L && L.mem.get(c.lbu); c.lb = ''; if (q && q.c === c) { q.c = null; q.at = Date.now(); lbPush(L); } }      // (3.5) из лобби: игрок не в сети
  if (c.w) { const wr = c.w; c.w = null; log('зритель ушёл | комната', wr.name, why ? '(' + why + ')' : ''); if (wr.watch) { wr.watch.delete(c); if (wr.lobby) { const L = lobbies.get(wr.lobby); if (L) lbPush(L); } } }      // (3.6) зритель ушёл
  const p = c.p, room = c.room; c.p = null; c.room = null;
  if (p && room) {
    const now = Date.now();
    if (room.mode === 'bomb') {
      if (p.alive && room.phase === 'live') dropBomb(room, p); else if (room.bomb.carrier === p.id) { room.bomb.carrier = 0; room.bomb.state = 'none'; }
      if (room.ranked && (room.phase === 'freeze' || room.phase === 'live' || room.phase === 'post')) { rate(p, false, room, now, true); saveRatings(); }
    }
    room.players.delete(p.id);
    const left = humans(room);
    log('выход:', p.name, '| комната', room.name, '| осталось', left, why ? '(' + why + ')' : '');
    if (left === 0) { room.players.clear(); rooms.delete(room.name); watchGone(room); }      // последний человек вышел: комната закрывается вместе с ботами
    else { broadcast(room, { t: 'leave', id: p.id }); if (room.host === p) room.host = null; fillBots(room, now); roundCheck(room, now); }
    if (room.lobby) { const L = lobbies.get(room.lobby); if (L) lbPush(L); }
  }
}
// сообщение об отказе, затем закрытие
function refuse(c, msg) { send(c, { t: 'err', msg: msg }); sendRaw(c, Buffer.from([0x88, 0])); setTimeout(() => drop(c, msg), 300); }

function onData(c, chunk) {
  c.buf = c.buf && c.buf.length ? Buffer.concat([c.buf, chunk]) : chunk;
  if (c.buf.length > 65536) { drop(c, 'flood'); return; }
  for (;;) {
    const b = c.buf; if (c.dead || !b || b.length < 2) return;
    const fin = b[0] & 0x80, op = b[0] & 0x0f, masked = b[1] & 0x80; let len = b[1] & 0x7f, off = 2;
    if (b[0] & 0x70) { drop(c, 'rsv'); return; }
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; } else if (len === 127) { drop(c, 'big'); return; }
    if (!masked || len > MAX_FRAME) { drop(c, 'frame'); return; }
    if (b.length < off + 4 + len) return;
    const data = Buffer.allocUnsafe(len);
    for (let i = 0; i < len; i++) data[i] = b[off + 4 + i] ^ b[off + (i & 3)];
    c.buf = b.subarray(off + 4 + len);
    if (op === 8) { sendRaw(c, Buffer.from([0x88, 0])); drop(c, ''); return; }
    if (op === 9) { if (len < 126) sendRaw(c, Buffer.concat([Buffer.from([0x8a, len]), data])); continue; }
    if (op === 10) continue;
    if (op === 0) { if (!c.frag) { drop(c, 'cont'); return; } c.frag.push(data); c.fragLen += len; }
    else if (op === 1 || op === 2) { if (c.frag) { drop(c, 'frag'); return; } c.frag = [data]; c.fragLen = len; c.fragText = op === 1; }
    else { drop(c, 'op'); return; }
    if (c.fragLen > MAX_FRAME * 2) { drop(c, 'big'); return; }
    if (fin) { const whole = c.frag.length === 1 ? c.frag[0] : Buffer.concat(c.frag), text = c.fragText; c.frag = null; if (text) onText(c, whole.toString('utf8')); }
  }
}

// ---- кто сейчас онлайн: игроки в комнатах и те, у кого игра открыта (она отмечается раз в полминуты) ----
const presence = new Map();
const PID_RE = /^[a-z0-9]{4,16}$/;
function mark(pid, now) { if (typeof pid === 'string' && PID_RE.test(pid) && (presence.has(pid) || presence.size < 5000)) presence.set(pid, now); }
// (3.2) для карточки «Онлайн» в меню: сколько людей в каждом режиме, сколько ещё ищут соперника, сколько боёв идёт, рекорд за сутки (UTC)
const peak = { day: '', n: 0 };
function onlineCount(now) {
  presence.forEach((at, pid) => { if (now - at > 75000) presence.delete(pid); });
  let n = presence.size, playing = 0, wait = 0, fights = 0; const modes = [0, 0, 0];
  rooms.forEach(r => {
    let h = 0; r.players.forEach(p => { if (p.bot) return; h++; playing++; if (!p.pid || !presence.has(p.pid)) n++; });
    if (!h) return;
    modes[r.ranked ? 2 : (r.mode === 'bomb' ? 1 : 0)] += h;
    if ((r.mode === 'bomb' && r.phase === 'wait') || (r.mode !== 'bomb' && h === 1 && !botCount(r))) wait += h; else fights++;      // один в комнате без ботов: ещё ищет
  });
  const day = new Date(now).toISOString().slice(0, 10);
  if (peak.day !== day) { peak.day = day; peak.n = 0; }
  if (n > peak.n) peak.n = n;
  return { n: n, playing: playing, modes: modes, wait: wait, fights: fights, peak: peak.n };
}

// ---- рейтинг: хранится в файле ratings.json рядом с сервером -----------------------------------
const ratings = Object.create(null);
try {
  const raw = JSON.parse(fs.readFileSync(RATE_FILE, 'utf8'));
  if (raw && typeof raw === 'object') for (const k of Object.keys(raw)) {
    const v = raw[k];
    if (UID_RE.test(k) && v && typeof v.r === 'number' && isFinite(v.r)) ratings[k] = { n: cleanName(v.n), r: Math.max(0, Math.min(9999, Math.round(v.r))), g: Math.max(0, v.g | 0), w: Math.max(0, v.w | 0), t: +v.t || 0 };
  }
} catch (e) { /* файла ещё нет: рейтинг начнётся с чистого листа */ }
let rateDirty = false;
function saveRatings() {
  if (!rateDirty) return; rateDirty = false;
  try { fs.writeFileSync(RATE_FILE + '.tmp', JSON.stringify(ratings)); fs.renameSync(RATE_FILE + '.tmp', RATE_FILE); } catch (e) { log('рейтинг не сохранился:', e && e.message); }
}
function rating(uid, name) {
  let r = ratings[uid];
  if (!r) { if (Object.keys(ratings).length >= 20000) return null; r = ratings[uid] = { n: name, r: 1000, g: 0, w: 0, t: Date.now() }; }
  if (name) r.n = name;
  return r;
}
// ---- голда (3.0): разовые коды и промокоды. Лежат в файле codes.json рядом с рейтингом --------
// Голду продаёт владелец игры: в игре (в разделе «Голда», он виден только админу) он создаёт разовый код
// на нужное число голды и отправляет его покупателю. Разовый код срабатывает один раз. Промокод (например,
// раз в месяц) вводит каждый игрок, но только один раз и пока не вышел срок.
// Создавать коды может только владелец: игра присылает число, сделанное из его админ-кода, а здесь лежит
// лишь отпечаток этого числа (SHA-256). Сам код и само число отсюда не узнать, даже если файл открыт всем.
const ADMIN_GOLD = '049eb0d705a6d7d5e4d71c013d4638bb7796e062627e79605f1c06520e50d585';
const CODE_FILE = process.env.CODES || path.join(path.dirname(RATE_FILE), 'codes.json');
const CODE_ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', CODE_RE = /^[A-ZА-ЯЁ0-9-]{3,24}$/;
const codes = { one: Object.create(null), promo: Object.create(null) };
try {
  const raw = JSON.parse(fs.readFileSync(CODE_FILE, 'utf8'));
  if (raw && raw.one) for (const k of Object.keys(raw.one)) { const v = raw.one[k]; if (CODE_RE.test(k) && v && v.g > 0) codes.one[k] = { g: v.g | 0, at: +v.at || 0, u: UID_RE.test(v.u) ? v.u : '', ut: +v.ut || 0 }; }
  if (raw && raw.promo) for (const k of Object.keys(raw.promo)) {
    const v = raw.promo[k]; if (!CODE_RE.test(k) || !v || !(v.g > 0)) continue;
    const u = Object.create(null); if (v.u) for (const id of Object.keys(v.u)) if (UID_RE.test(id)) u[id] = +v.u[id] || 1;
    codes.promo[k] = { g: v.g | 0, from: +v.from || 0, to: +v.to || 0, n: Object.keys(u).length, u: u };
  }
} catch (e) { /* файла ещё нет: кодов пока не создавали */ }
function saveCodes() {
  try { fs.writeFileSync(CODE_FILE + '.tmp', JSON.stringify(codes)); fs.renameSync(CODE_FILE + '.tmp', CODE_FILE); } catch (e) { log('коды не сохранились:', e && e.message); }
}
function cleanCode(v) { return String(v == null ? '' : v).replace(/\s+/g, '').toUpperCase().slice(0, 24); }
function newCode() {
  for (;;) {
    const b = crypto.randomBytes(8); let s = 'BS-';
    for (let i = 0; i < 8; i++) { if (i === 4) s += '-'; s += CODE_ABC[b[i] & 31]; }
    if (!codes.one[s] && !codes.promo[s]) return s;
  }
}
function isAdmin(tok) { return typeof tok === 'string' && /^[0-9a-f]{64}$/.test(tok) && crypto.createHash('sha256').update(tok).digest('hex') === ADMIN_GOLD; }
// неверные коды: не больше 10 за 10 минут с одного адреса, чтобы коды нельзя было подбирать
const codeTries = new Map();
// ---- (3.3) кланы ----
// Клан: тег из 2–5 букв или цифр (его видно в таблице боя у всех), название, цвет, глава и до 30 участников. Вступают по
// коду приглашения, его видят все участники; глава может сменить код, исключить участника и распустить клан. Уходит глава:
// главным становится тот, кто в клане дольше всех. Всё лежит в clans.json рядом с рейтингом.
const CLAN_FILE = process.env.CLANS || path.join(path.dirname(RATE_FILE), 'clans.json');
const CLAN_MAX = 30, CLAN_COLORS = 8, CLAN_TAG_RE = /^[A-ZА-ЯЁ0-9]{2,5}$/, CLAN_CODE_RE = /^K-[A-Z0-9]{6}$/, CLAN_BAD = ['BOT', 'БОТ', 'ADM', 'АДМ', 'АДМИН'];
const clans = Object.create(null), clanOf = Object.create(null), clanCodes = Object.create(null), clanMade = new Map();
function cleanClanName(v) { return String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f<>&"'`\\]/g, '').replace(/\s+/g, ' ').trim().slice(0, 24); }
function newClanCode() { for (;;) { const b = crypto.randomBytes(6); let s = 'K-'; for (let i = 0; i < 6; i++) s += CODE_ABC[b[i] & 31]; if (!clanCodes[s]) return s; } }
try {
  const raw = JSON.parse(fs.readFileSync(CLAN_FILE, 'utf8'));
  for (const id of Object.keys(raw || {})) {
    const k = raw[id]; if (!k || !CLAN_TAG_RE.test(k.tag) || !k.m) continue;
    const m = Object.create(null); for (const u of Object.keys(k.m)) if (UID_RE.test(u) && !clanOf[u]) { const v = k.m[u] || {}; m[u] = { n: cleanName(v.n), j: +v.j || 0, s: +v.s || 0 }; }
    const us = Object.keys(m); if (!us.length) continue;
    const own = m[k.own] ? k.own : us.sort((a, b) => m[a].j - m[b].j)[0], code = CLAN_CODE_RE.test(k.code) && !clanCodes[k.code] ? k.code : newClanCode();
    clans[id] = { id: id, tag: k.tag, name: cleanClanName(k.name) || k.tag, col: Math.abs(k.col | 0) % CLAN_COLORS, own: own, code: code, at: +k.at || 0, m: m };
    clanCodes[code] = id; for (const u of us) clanOf[u] = id;
  }
} catch (e) { /* файла ещё нет: кланов пока не создавали */ }
let clanTm = null;
function clanSave() {
  if (clanTm) return;
  clanTm = setTimeout(() => { clanTm = null; try { fs.writeFileSync(CLAN_FILE + '.tmp', JSON.stringify(clans)); fs.renameSync(CLAN_FILE + '.tmp', CLAN_FILE); } catch (e) { log('кланы не сохранились:', e && e.message); } }, 1500);
}
function clanKey(u) { return crypto.createHash('sha256').update('clan:' + u).digest('hex').slice(0, 12); }      // участник для других: не сам uid
function clanTagOf(u) { const k = clanOf[u] ? clans[clanOf[u]] : null; return k ? { t: k.tag, c: k.col } : null; }
// без участника: уходит глава, главным становится тот, кто в клане дольше всех; ушёл последний: клана больше нет
function clanRemove(k, u) {
  delete k.m[u]; delete clanOf[u];
  const left = Object.keys(k.m);
  if (!left.length) { delete clanCodes[k.code]; delete clans[k.id]; log('клан распался:', k.tag); return; }
  if (k.own === u) k.own = left.sort((a, b) => k.m[a].j - k.m[b].j)[0];
}
// что видит участник: тег, название, цвет, код приглашения, кто в клане и кто сейчас в бою или в сети
function clanView(k, uid, now) {
  const fighting = new Set(); rooms.forEach(r => r.players.forEach(p => { if (p.uid) fighting.add(p.uid); }));
  const list = Object.keys(k.m).map(u => { const v = k.m[u], st = fighting.has(u) ? 2 : (now - v.s < 90000 ? 1 : 0);
    return { k: clanKey(u), n: v.n, o: u === k.own ? 1 : 0, me: u === uid ? 1 : 0, st: st, ago: st ? 0 : Math.max(0, Math.round((now - v.s) / 60000)) }; });
  list.sort((a, b) => b.o - a.o || b.st - a.st || a.ago - b.ago || (a.n < b.n ? -1 : 1));
  return { tag: k.tag, name: k.name, col: k.col, code: k.code, own: k.own === uid ? 1 : 0, max: CLAN_MAX, m: list };
}
function onClan(c, m, now) {
  const uid = typeof m.u === 'string' && UID_RE.test(m.u) ? m.u : '', ip = c.ip || '', reply = o => send(c, Object.assign({ t: 'clan' }, o));
  if (!uid) { reply({ ok: 0, why: 'uid' }); return; }
  const nick = cleanName(m.n); let k = clanOf[uid] ? clans[clanOf[uid]] : null;
  if (k) { const me = k.m[uid]; me.s = now; if (m.n && me.n !== nick) { me.n = nick; clanSave(); } }
  const owner = () => { if (!k || k.own !== uid) { reply({ ok: 0, why: 'own', clan: k ? clanView(k, uid, now) : null }); return false; } return true; };
  switch (m.op) {
    case 'get': break;
    case 'make': {
      if (k) { reply({ ok: 0, why: 'have', clan: clanView(k, uid, now) }); return; }
      const made = clanMade.get(ip); if (made && now - made.at < 3600000 && made.n >= 3) { reply({ ok: 0, why: 'many' }); return; }
      const tag = String(m.tag == null ? '' : m.tag).replace(/\s+/g, '').toUpperCase(), name = cleanClanName(m.name);
      if (!CLAN_TAG_RE.test(tag) || CLAN_BAD.indexOf(tag) >= 0) { reply({ ok: 0, why: 'tag' }); return; }
      if (name.length < 3) { reply({ ok: 0, why: 'name' }); return; }
      for (const id of Object.keys(clans)) if (clans[id].tag === tag) { reply({ ok: 0, why: 'taken' }); return; }
      if (Object.keys(clans).length >= 20000) { reply({ ok: 0, why: 'many' }); return; }
      let id; do { id = crypto.randomBytes(5).toString('hex'); } while (clans[id]);
      k = clans[id] = { id: id, tag: tag, name: name, col: Math.abs(m.col | 0) % CLAN_COLORS, own: uid, code: newClanCode(), at: now, m: Object.create(null) };
      k.m[uid] = { n: nick, j: now, s: now }; clanOf[uid] = id; clanCodes[k.code] = id;
      if (!made || now - made.at > 3600000) clanMade.set(ip, { n: 1, at: now }); else made.n++; if (clanMade.size > 5000) clanMade.clear();
      clanSave(); log('клан создан:', tag, '|', name); break;
    }
    case 'join': {
      if (k) { reply({ ok: 0, why: 'have', clan: clanView(k, uid, now) }); return; }
      if (codeBlocked(ip, now)) { reply({ ok: 0, why: 'wait' }); return; }
      const code = cleanCode(m.code).replace(/^K(?!-)/, 'K-'), kk = CLAN_CODE_RE.test(code) && clanCodes[code] ? clans[clanCodes[code]] : null;
      if (!kk) { codeMiss(ip, now); reply({ ok: 0, why: 'code' }); return; }
      if (Object.keys(kk.m).length >= CLAN_MAX) { reply({ ok: 0, why: 'full' }); return; }
      kk.m[uid] = { n: nick, j: now, s: now }; clanOf[uid] = kk.id; k = kk; clanSave(); log('в клан', kk.tag, 'вступил', nick); break;
    }
    case 'leave': if (k) { clanRemove(k, uid); k = null; clanSave(); } break;
    case 'kick': {
      if (!owner()) return;
      const who = Object.keys(k.m).find(u => clanKey(u) === m.who);
      if (!who || who === uid) { reply({ ok: 0, why: 'who', clan: clanView(k, uid, now) }); return; }
      clanRemove(k, who); clanSave(); break;
    }
    case 'code': if (!owner()) return; delete clanCodes[k.code]; k.code = newClanCode(); clanCodes[k.code] = k.id; clanSave(); break;
    case 'drop': {
      if (!owner()) return;
      for (const u of Object.keys(k.m)) delete clanOf[u]; delete clanCodes[k.code]; delete clans[k.id]; log('клан распущен:', k.tag); k = null; clanSave(); break;
    }
    default: reply({ ok: 0, why: 'op' }); return;
  }
  reply({ ok: 1, clan: k ? clanView(k, uid, now) : null });
}
function codeBlocked(ip, now) { const t = codeTries.get(ip); return !!t && now - t.at < 600000 && t.n >= 10; }
function codeMiss(ip, now) { const t = codeTries.get(ip); if (!t || now - t.at > 600000) codeTries.set(ip, { n: 1, at: now }); else t.n++; if (codeTries.size > 5000) codeTries.clear(); }
// игрок вводит код. Тот же код с того же устройства ещё раз отвечает так же: игра сама не даст голду дважды
// (если ответ потерялся по дороге, голда всё равно дойдёт со второй попытки)
function onCode(c, m, now) {
  const ip = c.ip || '', no = msg => { codeMiss(ip, now); send(c, { t: 'code', ok: 0, msg: msg }); };
  if (codeBlocked(ip, now)) { send(c, { t: 'code', ok: 0, msg: 'Слишком много неверных кодов. Попробуй через 10 минут.' }); return; }
  const uid = typeof m.uid === 'string' && UID_RE.test(m.uid) ? m.uid : '', key = cleanCode(m.code);
  if (!uid) { send(c, { t: 'code', ok: 0, msg: 'Обнови игру' }); return; }
  const one = CODE_RE.test(key) ? codes.one[key] : null;
  if (one) {
    if (one.u && one.u !== uid) { no('Этот код уже использован'); return; }
    if (!one.u) { one.u = uid; one.ut = now; saveCodes(); log('код', key, '| голда', one.g, '| игрок', uid.slice(0, 6)); if (accs[uid]) { accs[uid].g += one.g; accLog(accs[uid], 'код ' + key + ': +' + one.g); accSave(); } }
    send(c, { t: 'code', ok: 1, g: one.g, id: key, bal: accs[uid] ? accs[uid].g : undefined }); return;
  }
  const pr = CODE_RE.test(key) ? codes.promo[key] : null;
  if (pr) {
    if (!pr.u[uid]) {
      if (now > pr.to) { send(c, { t: 'code', ok: 0, msg: 'Срок этого промокода закончился' }); return; }
      if (pr.n >= 200000) { send(c, { t: 'code', ok: 0, msg: 'Промокод закончился' }); return; }
      pr.u[uid] = now; pr.n++; saveCodes();
      if (accs[uid]) { accs[uid].g += pr.g; accLog(accs[uid], 'промокод ' + key + ': +' + pr.g); accSave(); }
    }
    send(c, { t: 'code', ok: 1, g: pr.g, id: 'P:' + key + ':' + pr.from, bal: accs[uid] ? accs[uid].g : undefined }); return;
  }
  no('Такого кода нет');
}
// владелец: создать разовые коды, запустить промокод, удалить код, посмотреть список
function onAdm(c, m, now) {
  const ip = c.ip || '';
  if (codeBlocked(ip, now)) { send(c, { t: 'adm', ok: 0, op: String(m.op || ''), msg: 'Слишком много попыток. Подожди 10 минут.' }); return; }
  if (!isAdmin(m.tok)) { codeMiss(ip, now); send(c, { t: 'adm', ok: 0, op: String(m.op || ''), msg: 'Нет доступа: введи админ-код ещё раз' }); return; }
  const g = Math.floor(num(m.g, 0, 1000000, 0)), out = { t: 'adm', ok: 1, op: m.op };
  if (!admOps(c, m, now, out)) return;          // (3.5) игроки, рынок, лобби, объявление
  if (m.op === 'make') {
    const n = Math.floor(num(m.n, 1, 20, 1)); if (g < 1) { send(c, { t: 'adm', ok: 0, msg: 'Сколько голды?' }); return; }
    if (Object.keys(codes.one).length + n > 5000) {      // старые использованные коды больше не нужны
      for (const k of Object.keys(codes.one)) if (codes.one[k].u && now - codes.one[k].ut > 90 * 864e5) delete codes.one[k];
      if (Object.keys(codes.one).length + n > 5000) { send(c, { t: 'adm', ok: 0, msg: 'Слишком много неиспользованных кодов' }); return; }
    }
    out.codes = []; for (let i = 0; i < n; i++) { const k = newCode(); codes.one[k] = { g: g, at: now, u: '', ut: 0 }; out.codes.push(k); }
    out.g = g; saveCodes(); log('владелец создал кодов:', n, 'по', g, 'голды');
  } else if (m.op === 'promo') {
    const key = cleanCode(m.code), days = Math.floor(num(m.days, 1, 90, 30));
    if (!CODE_RE.test(key) || key.length > 20) { send(c, { t: 'adm', ok: 0, msg: 'Промокод: от 3 до 20 букв и цифр' }); return; }
    if (codes.one[key]) { send(c, { t: 'adm', ok: 0, msg: 'Такой разовый код уже есть' }); return; }
    if (g < 1 || g > 100000) { send(c, { t: 'adm', ok: 0, msg: 'Сколько голды?' }); return; }
    const old = codes.promo[key];      // тот же промокод ещё раз: новый срок и сумма, а кто уже вводил, второй раз не получит
    codes.promo[key] = { g: g, from: old ? old.from : now, to: now + days * 864e5, n: old ? old.n : 0, u: old ? old.u : Object.create(null) };
    if (Object.keys(codes.promo).length > 50) { let o = null; for (const k of Object.keys(codes.promo)) if (k !== key && (!o || codes.promo[k].to < codes.promo[o].to)) o = k; if (o) delete codes.promo[o]; }
    saveCodes(); log('владелец запустил промокод', key, '| голда', g, '| дней', days);
  } else if (m.op === 'del') {
    const key = cleanCode(m.code);
    if (codes.one[key]) delete codes.one[key]; else if (codes.promo[key]) delete codes.promo[key]; else { send(c, { t: 'adm', ok: 0, msg: 'Такого кода нет' }); return; }
    saveCodes();
  } else if (m.op !== 'list') { send(c, { t: 'adm', ok: 0, msg: 'Обнови игру' }); return; }
  const ones = Object.keys(codes.one).map(k => ({ c: k, g: codes.one[k].g, at: codes.one[k].at, u: codes.one[k].u ? 1 : 0, ut: codes.one[k].ut }));
  ones.sort((a, b) => b.at - a.at);
  out.one = ones.slice(0, 40); out.free = ones.filter(x => !x.u).length; out.used = ones.length - out.free;
  out.promo = Object.keys(codes.promo).map(k => ({ c: k, g: codes.promo[k].g, to: codes.promo[k].to, n: codes.promo[k].n })).sort((a, b) => b.to - a.to);
  out.now = now; send(c, out);
}
function topList(uid) {
  const all = Object.keys(ratings).filter(k => ratings[k].g > 0).sort((a, b) => ratings[b].r - ratings[a].r || ratings[b].w - ratings[a].w);
  const list = all.slice(0, 50).map(k => ({ n: ratings[k].n, r: ratings[k].r, g: ratings[k].g, w: ratings[k].w, me: k === uid ? 1 : 0 }));
  const mine = uid && ratings[uid] ? ratings[uid] : null;
  return { t: 'top', list: list, place: uid ? all.indexOf(uid) + 1 : 0, r: mine ? mine.r : 1000, g: mine ? mine.g : 0 };
}
// итог рейтингового матча для одного игрока: чем сильнее соперники, тем больше за победу и меньше за поражение
// (3.3) рейтинг 2×2 (ММР): победа даёт от +17 до +42, поражение отнимает от 10 до 30. Сколько именно, решает игра бойца:
// его доля убийств в матче, убийства против смертей, заложенные и разминированные бомбы, и немного случай. Лучший в матче
// (MVP) получает за победу не меньше +34, а за поражение теряет не больше 14. Ушедший из идущего матча теряет 30.
const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
function score(p) { return (p.kills | 0) * 2 + (p.obj | 0) * 2 - (p.deaths | 0) * 0.5; }
function mvpOf(room) { let best = null; room.players.forEach(q => { if (q.bot) return; if (!best || score(q) > score(best) || (score(q) === score(best) && q.deaths < best.deaths)) best = q; }); return best; }
function rate(p, won, room, now, left) {
  const r = p.uid ? rating(p.uid, p.name) : null; if (!r) return;
  let d, why, mvp = false;
  if (left) { d = -30; why = 'вышел из матча'; }
  else {
    let top = 1; room.players.forEach(q => { if (!q.bot && q.kills > top) top = q.kills; });
    const k = p.kills | 0, dd = p.deaths | 0, ob = p.obj | 0;
    const perf = clampN(0.5 * k / top + 0.35 * Math.min(1, k / Math.max(1, dd) / 2) + 0.15 * Math.min(1, ob / 2), 0, 1);
    mvp = mvpOf(room) === p && k > 0;
    if (won) { d = 17 + Math.round(perf * 20) + rnd(0, 5); if (mvp) d = Math.max(d, 34 + rnd(0, 4)); d = Math.min(42, Math.max(17, d)); }
    else { d = -(30 - Math.round(perf * 16) - rnd(0, 4)); if (mvp) d = Math.max(d, -14 + rnd(-2, 0)); d = Math.max(-30, Math.min(-10, d)); }
    why = (mvp ? 'MVP: ' : '') + k + ' ' + plural(k, 'убийство', 'убийства', 'убийств') + ', ' + dd + ' ' + plural(dd, 'смерть', 'смерти', 'смертей') + (ob ? ', бомба: ' + ob : '');
  }
  const old = r.r; r.r = Math.max(0, old + d); r.g++; if (won) r.w++; r.t = now; rateDirty = true;
  send(p.c, { t: 'rate', old: old, now: r.r, d: r.r - old, g: r.g, mvp: mvp ? 1 : 0, why: why });
}
function clampN(v, a, b) { return v < a ? a : v > b ? b : v; }
function plural(n, one, few, many) { n = Math.abs(n) % 100; const m = n % 10; return n > 10 && n < 20 ? many : m === 1 ? one : m >= 2 && m <= 4 ? few : many; }
function avgRating(room, grp) { let s = 0, n = 0; room.players.forEach(p => { if (p.grp === grp) { const r = p.uid && ratings[p.uid]; s += r ? r.r : 1000; n++; } }); return n ? s / n : 1000; }

// ---- игра -------------------------------------------------------------------------------------
function pub(p) {
  if (p.bot) return { id: p.id, name: p.name, team: p.team, alive: p.alive, kills: p.kills, deaths: p.deaths, bot: 1 };
  const o = { id: p.id, name: p.name, team: p.team, alive: p.alive, kills: p.kills, deaths: p.deaths }; if (p.admin) o.adm = 1; if (p.clan) o.cl = [p.clan.t, p.clan.c]; return o;
}
function newRoom(name, now, mode, map, ranked) {
  const room = { name: name, players: new Map(), nextId: 1, score: { ct: 0, t: 0 }, state: 'live', endsAt: now + MATCH_MS, postUntil: 0, tick: 0,
    mode: mode === 'bomb' ? 'bomb' : 'tdm', map: (mode === 'bomb' ? BOMB_MAPS : ANY_MAPS).indexOf(map) >= 0 ? map : 'town', ranked: !!ranked, size: ranked ? 4 : ROOM_SIZE,
    phase: 'wait', phaseEnd: 0, liveAt: 0, round: 0, wins: [0, 0], side: ['ct', 't'], swapped: false, bomb: { state: 'none', carrier: 0, x: 0, y: 0, z: 0, at: 0 },
    botsOn: false, host: null, botAt: 0, drops: new Map(), nextDrop: 1 };
  rooms.set(name, room); return room;
}
function fighting(room) { return room.state === 'live' && (room.mode !== 'bomb' || room.phase === 'live'); }
function spawn(room, p, now) {
  p.alive = true; p.hp = 100; p.armor = 100; p.helmet = true; p.protectUntil = now + PROTECT_MS; p.respawnAt = 0; p.st = null; p.extra = null; p.nades = { he: 1, flash: 1 }; p.dmgBy = null;      // (подобранное оружие осталось в прошлой жизни)
  broadcast(room, { t: 'spawn', id: p.id });
}
function endMatch(room, now) {
  if (room.state !== 'live') return;
  room.state = 'post'; room.postUntil = now + POST_MS;
  const s = room.score, win = s.ct === s.t ? null : (s.ct > s.t ? 'ct' : 't');
  broadcast(room, { t: 'end', win: win, s: [s.ct, s.t] });
  log('матч окончен | комната', room.name, '| счёт', s.ct + ':' + s.t);
  if (room.lobby) lbMatchOver(room, { text: (win ? (win === 'ct' ? 'победил спецназ' : 'победили террористы') : 'ничья') + ' · ' + s.ct + ':' + s.t, w: [s.ct, s.t], map: room.map, at: now });
}
function startMatch(room, now) {
  room.state = 'live'; room.endsAt = now + MATCH_MS; room.score.ct = 0; room.score.t = 0; room.drops.clear();
  room.players.forEach(p => { p.kills = 0; p.deaths = 0; p.obj = 0; p.alive = false; p.respawnAt = 0; p.assists = 0; p.dmg = 0; p.mvps = 0; p.hs = 0; });
  broadcast(room, { t: 'start', left: MATCH_MS, limit: room.limit || KILL_LIMIT });
  room.players.forEach(p => spawn(room, p, now));
}

// ---- раунды с бомбой --------------------------------------------------------------------------
function count(room, team, aliveOnly) { let n = 0; room.players.forEach(p => { if (p.team === team && (!aliveOnly || p.alive)) n++; }); return n; }
function bombMsg(room, e, id, money) { const b = room.bomb, m = { t: 'bomb', e: e, id: id || 0, x: b.x, y: b.y, z: b.z }; if (money !== undefined) m.m = money; broadcast(room, m); }
function dropBomb(room, p) {
  const b = room.bomb; if (b.state !== 'carried' || b.carrier !== p.id) return;
  let other = null; room.players.forEach(q => { if (!other && q !== p && q.alive && q.team === 't') other = q; });
  if (p.st) { b.state = 'dropped'; b.carrier = 0; b.x = p.st[1]; b.y = p.st[2]; b.z = p.st[3]; bombMsg(room, 'drop'); }
  else if (other) { b.carrier = other.id; bombMsg(room, 'pick', other.id); }       // где упала, неизвестно: бомба переходит напарнику
  else { b.state = 'none'; b.carrier = 0; }
}
function startBomb(room, now) {
  room.wins = [0, 0]; room.round = 0; room.swapped = false; room.state = 'live'; room.fresh = true; room.streak = { ct: 0, t: 0 };
  room.players.forEach(p => { p.kills = 0; p.deaths = 0; p.obj = 0; p.assists = 0; p.dmg = 0; p.mvps = 0; p.hs = 0; p.rk = 0; });
  log('матч с бомбой начался | комната', room.name, room.ranked ? '| рейтинговый' : '', '| игроков', room.players.size);
  nextRound(room, now);
}
function nextRound(room, now) {
  room.round++;
  let swap = false, half = !!room.fresh;
  if (!room.swapped && room.round === (room.need || NEED)) {                       // середина матча: команды меняются сторонами
    room.swapped = true; room.side.reverse(); swap = half = true;
    room.players.forEach(p => { p.team = p.team === 'ct' ? 't' : 'ct'; });
  }
  room.fresh = false; if (half) room.streak = { ct: 0, t: 0 }; room.planted = false;
  room.fires = []; room.smokes = []; room.nades = new Map();
  room.players.forEach(p => { p.rk = 0; p.dmgBy = null; }); room.bomb.planter = 0; room.bomb.defuser = 0;
  const teams = [], ts = [], inv = []; room.drops.clear();      // новый раунд: с земли всё убрано
  room.players.forEach(p => {
    // выживший в прошлом раунде оставляет оружие и броню (какой осталась); погибший и новенький начинают с пистолетом своей стороны.
    // Первый раунд половины пистолетный у всех: $800 и пистолет
    const kept = !half && p.alive && !p.fresh;
    if (half) p.money = MONEY.start;
    if (kept) { p.kev = Math.round(p.armor); p.helm = p.helmet && p.kev > 0; }
    else { p.gun = { primary: '', secondary: DEFAULT_PISTOL[p.team] }; p.kev = 0; p.helm = false; p.nades = {}; }
    p.fresh = false;
    p.alive = true; p.hp = 100; p.armor = p.kev; p.helmet = p.helm; p.protectUntil = 0; p.respawnAt = 0; p.st = null; p.act = null; p.extra = null;
    teams.push([p.id, p.team]); inv.push(kitMsg(p)); if (p.team === 't') ts.push(p);
  });
  const b = room.bomb; b.state = ts.length ? 'carried' : 'none'; b.carrier = ts.length ? ts[Math.floor(Math.random() * ts.length)].id : 0; b.at = 0;
  const freeze = FREEZE_MS + (half ? HALF_FREEZE_MS : 0);
  room.phase = 'freeze'; room.phaseEnd = now + freeze;
  broadcast(room, { t: 'round', n: room.round, wins: room.wins, side: room.side, teams: teams, carrier: b.carrier, freeze: freeze, eco: 1, pistol: half ? 1 : 0, swap: swap ? 1 : 0, inv: inv });
}
// снаряжение игрока для игры: [номер, деньги, основное (место в списке оружия или -1), пистолет, броня, шлем]
function kitMsg(p) { return [p.id, p.money, p.gun.primary ? W_IDS.indexOf(p.gun.primary) : -1, p.gun.secondary ? W_IDS.indexOf(p.gun.secondary) : -1, Math.round(p.armor), p.helmet ? 1 : 0, NADE_IDS.map(id => (p.nades && p.nades[id]) | 0)]; }
function nadeTotal(p) { let n = 0; for (const id of NADE_IDS) n += (p.nades && p.nades[id]) | 0; return n; }
// деньги за раунд: победителям поровну, проигравшим тем больше, чем дольше они проигрывают подряд
function payRound(room, win) {
  const lose = win === 'ct' ? 't' : 'ct', st = room.streak || (room.streak = { ct: 0, t: 0 });
  st[win] = 0; st[lose] = Math.min(st[lose] + 1, 5);
  const loss = MONEY.loss + MONEY.step * Math.min(st[lose] - 1, 4);
  room.players.forEach(p => { p.money = Math.min(MONEY.max, p.money + (p.team === win ? MONEY.win : loss + (p.team === 't' && room.planted ? MONEY.planted : 0))); });
}
// покупка: во время заморозки и первые 15 секунд раунда, своей стороны, на свои деньги. Ответ всегда несёт деньги и снаряжение,
// какими их знает сервер: если игра поторопилась, она поправит себя
function buy(room, p, what, now) {
  const no = why => send(p.c, { t: 'buy', ok: 0, why: why, kit: kitMsg(p) });
  if (room.mode !== 'bomb') return;
  if (!p.alive || !(room.phase === 'freeze' || (room.phase === 'live' && now - room.liveAt < BUY_MS + 1000))) { no('time'); return; }      // секунда в запас: покупка в последний миг ещё в пути
  if (typeof what === 'string' && NADE[what]) {
    const d = NADE[what]; p.nades = p.nades || {};
    if (d.side && d.side !== p.team) { no('side'); return; }
    if ((p.nades[what] | 0) >= d.max || nadeTotal(p) >= NADE_MAX) { no('nades'); return; }
    if (p.money < d.price) { no('money'); return; }
    p.money -= d.price; p.nades[what] = (p.nades[what] | 0) + 1;
  } else if (what === 'vest' || what === 'vesthelm') {
    const price = GEAR_PRICE[what];
    if (p.armor >= 100 && (what === 'vest' || p.helmet)) { no('have'); return; }
    if (p.money < price) { no('money'); return; }
    p.money -= price; p.armor = 100; if (what === 'vesthelm') p.helmet = true;
  } else {
    const id = W_IDS[num(what, -1, 99, -1) | 0], pr = id && PRICE[id];
    if (!pr) { no('what'); return; }
    if (SIDE[id] && SIDE[id] !== p.team) { no('side'); return; }
    if (p.money < pr[0]) { no('money'); return; }
    p.money -= pr[0]; p.gun[PISTOLS[id] ? 'secondary' : 'primary'] = id;
  }
  send(p.c, { t: 'buy', ok: 1, kit: kitMsg(p) });
}
// стрелять в раундах с бомбой можно только из своего: купленного, выданного в начале раунда или подобранного с земли
function ownsGun(room, p, wid) { return room.mode !== 'bomb' || p.gun.primary === wid || p.gun.secondary === wid || !!(p.extra && p.extra[wid]); }
function endRound(room, win, why, now) {
  if (room.phase !== 'live') return;
  room.phase = 'post'; room.phaseEnd = now + ROUND_POST_MS;
  room.wins[room.side.indexOf(win)]++;
  room.players.forEach(p => { p.act = null; });
  payRound(room, win);
  // (3.4) лучший раунда: заложивший бомбу, если она взорвалась; разминировавший; иначе из победителей тот, кто убил больше
  let mvp = null; const b = room.bomb;
  if (why === 'boom' && b.planter) mvp = room.players.get(b.planter) || null; else if (why === 'defuse' && b.defuser) mvp = room.players.get(b.defuser) || null;
  if (!mvp) room.players.forEach(p => { if (p.team === win && (p.rk | 0) > 0 && (!mvp || (p.rk | 0) > (mvp.rk | 0))) mvp = p; });
  if (mvp) mvp.mvps = (mvp.mvps | 0) + 1;
  const mon = []; room.players.forEach(p => mon.push([p.id, p.money]));
  broadcast(room, { t: 'rend', win: win, why: why, wins: room.wins, mon: mon, mvp: mvp ? mvp.id : 0 });
}
function endBomb(room, now) {
  const g = room.wins[0] >= room.wins[1] ? 0 : 1;
  room.phase = 'over'; room.phaseEnd = now + POST_MS; room.bomb.state = 'none';
  broadcast(room, { t: 'end', win: room.side[g], s: room.wins, g: g });
  log('матч с бомбой окончен | комната', room.name, '| счёт', room.wins[0] + ':' + room.wins[1]);
  if (room.lobby) {
    const names = []; room.players.forEach(p => { if (!p.bot && p.grp === g) names.push(p.name); });
    lbMatchOver(room, { text: (names.length ? 'победили ' + names.join(', ') : 'матч окончен') + ' · ' + Math.max(room.wins[0], room.wins[1]) + ':' + Math.min(room.wins[0], room.wins[1]), w: room.wins.slice(), map: room.map, at: now });
  }
  if (room.ranked) { room.players.forEach(p => rate(p, p.grp === g, room, now, false)); saveRatings(); }
}
function roundCheck(room, now) {
  if (room.mode !== 'bomb' || room.phase !== 'live') return;
  const ct = count(room, 'ct', true), t = count(room, 't', true);
  if (!ct) endRound(room, 't', 'kill', now); else if (!t && room.bomb.state !== 'planted') endRound(room, 'ct', 'kill', now);
}
function near(p, x, y, z, r) { return !!p.st && Math.hypot(p.st[1] - x, p.st[3] - z) <= r && Math.abs(p.st[2] - y) <= 70; }
function tickBomb(room, now) {
  const b = room.bomb, ct = count(room, 'ct'), t = count(room, 't');
  if (room.phase === 'wait') {
    // (3.5) матч лобби: когда зашли все, кого позвали (или через 30 секунд, если в обеих командах кто-то есть)
    if (room.allow) { if (ct && t && (humans(room) >= room.allow.size || now - room.made > 30000)) startBomb(room, now); return; }
    // обычная комната начинает, как только в обеих командах кто-то есть; рейтинговая строго вчетвером, двое на двое
    if (room.ranked ? ct === 2 && t === 2 : ct && t) startBomb(room, now);
    return;
  }
  if (room.phase === 'over') { if (room.allow) return; if (now >= room.phaseEnd) { if (room.ranked ? ct === 2 && t === 2 : ct && t) startBomb(room, now); else room.phase = 'wait'; } return; }
  if (!ct || !t) {                                                   // одна из команд вышла целиком: победа оставшимся
    const g = room.side.indexOf(ct ? 'ct' : 't'), need = room.need || NEED; room.wins[g] = Math.max(room.wins[g], need); room.wins[1 - g] = Math.min(room.wins[1 - g], need - 1);
    endBomb(room, now); return;
  }
  if (room.phase === 'freeze') { if (now >= room.phaseEnd) { room.phase = 'live'; room.liveAt = now; broadcast(room, { t: 'live', left: ROUND_MS, buy: BUY_MS }); } return; }
  if (room.phase === 'post') { if (now >= room.phaseEnd) { if (room.wins[0] >= (room.need || NEED) || room.wins[1] >= (room.need || NEED)) endBomb(room, now); else nextRound(room, now); } return; }
  // идёт раунд
  if (b.state === 'dropped') room.players.forEach(p => { if (b.state === 'dropped' && p.alive && p.team === 't' && near(p, b.x, b.y, b.z, 44)) { b.state = 'carried'; b.carrier = p.id; bombMsg(room, 'pick', p.id); } });
  room.players.forEach(p => {
    const a = p.act; if (!a || room.phase !== 'live') return;
    if (!p.alive || !near(p, a.x, a.y, a.z, 40)) { p.act = null; return; }
    if (a.k === 'p' && now - a.at >= PLANT_MS && b.state === 'carried' && b.carrier === p.id) {
      p.act = null; b.state = 'planted'; b.carrier = 0; b.x = p.st[1]; b.y = p.st[2]; b.z = p.st[3]; b.at = now; room.planted = true; b.planter = p.id;
      p.money = Math.min(MONEY.max, p.money + MONEY.plant); p.obj = (p.obj | 0) + 1; bombMsg(room, 'plant', p.id, p.money);
    } else if (a.k === 'd' && now - a.at >= DEFUSE_MS && b.state === 'planted') {
      p.act = null; b.state = 'none'; p.money = Math.min(MONEY.max, p.money + MONEY.defuse); p.obj = (p.obj | 0) + 1; b.defuser = p.id; bombMsg(room, 'defuse', p.id, p.money); endRound(room, 'ct', 'defuse', now);
    }
  });
  if (room.phase !== 'live') return;
  if (b.state === 'planted') {
    if (now - b.at >= FUSE_MS) {
      b.state = 'none'; bombMsg(room, 'boom'); endRound(room, 't', 'boom', now);
      room.players.forEach(p => { if (p.alive && p.st) { const dmg = bombDamage(Math.hypot(p.st[1] - b.x, p.st[2] + 36 - b.y, p.st[3] - b.z)); if (dmg >= 1) damage(room, p, null, dmg, 2, 0.6, 'bomb', now); } });
    }
  } else if (now - room.liveAt >= ROUND_MS) endRound(room, 'ct', 'time', now);
}
function bombAct(room, p, what, now) {
  if (room.mode !== 'bomb') return;
  const b = room.bomb;
  if (what === 'x' || room.phase !== 'live' || !p.alive || !p.st) { p.act = null; return; }
  if (what === 'p') {
    const zs = BOMB_ZONE[room.map] || [], inZone = zs.some(z => p.st[1] >= z[0] && p.st[1] <= z[2] && p.st[3] >= z[1] && p.st[3] <= z[3]);
    if (p.team !== 't' || b.state !== 'carried' || b.carrier !== p.id || !inZone) return;
    p.act = { k: 'p', at: now, x: p.st[1], y: p.st[2], z: p.st[3] };
  } else if (what === 'd') {
    if (p.team !== 'ct' || b.state !== 'planted' || !near(p, b.x, b.y, b.z, 70)) return;
    p.act = { k: 'd', at: now, x: p.st[1], y: p.st[2], z: p.st[3] };
  }
}

// ---- оружие на земле ---------------------------------------------------------------------------
// что выпало: номер (по нему его просят), оружие и скин, как их назвала игра хозяина, и где он стоял
function addDrop(room, widx, skin, st, now) {
  if (!st || !(widx >= 0 && widx < W_IDS.length)) return null;          // нож в руках (или о бойце ещё ничего не известно): ничего не падает
  const d = { id: room.nextDrop++, w: widx, skin: skin | 0, x: st[1], y: st[2], z: st[3], at: now };
  room.drops.set(d.id, d);
  if (room.drops.size > DROP_MAX) room.drops.delete(room.drops.keys().next().value);      // самое старое убирается
  return d;
}
function dropMsg(d) { return [d.id, d.w, d.skin, d.x, d.y, d.z]; }
function kill(room, victim, attacker, wid, head, now) {
  const bombRoom = room.mode === 'bomb';
  victim.alive = false; victim.hp = 0; victim.deaths++; victim.respawnAt = bombRoom ? 0 : now + RESPAWN_MS; victim.act = null;
  if (attacker && attacker !== victim) { attacker.kills++; attacker.rk = (attacker.rk | 0) + 1; if (head) attacker.hs = (attacker.hs | 0) + 1; if (attacker.team !== victim.team && !bombRoom) room.score[attacker.team]++; }
  // (3.4) помощь: кто из противников убитого снял с него за эту жизнь 40 и больше, но не добил
  if (victim.dmgBy) { victim.dmgBy.forEach((d, id) => { const a = room.players.get(id); if (a && a !== attacker && a.team !== victim.team && d >= 40) a.assists = (a.assists | 0) + 1; }); victim.dmgBy = null; }
  const held = victim.st ? victim.st[7] | 0 : -1;
  victim.nades = {};          // (3.4) гранаты погибшего пропадают          // что было в руках; в раундах с деньгами падает только своё (купленное, выданное, подобранное)
  const fell = victim.st && (!bombRoom || ownsGun(room, victim, W_IDS[held])) ? addDrop(room, held, victim.st[9] | 0, victim.st, now) : null;
  const msg = { t: 'kill', v: victim.id, k: attacker && attacker !== victim ? attacker.id : -1, w: wid, h: head ? 1 : 0, s: bombRoom ? null : [room.score.ct, room.score.t] };
  if (bombRoom && attacker && attacker !== victim && attacker.team !== victim.team) { attacker.money = Math.min(MONEY.max, attacker.money + (PRICE[wid] ? PRICE[wid][1] : (wid === 'he' || wid === 'fire' ? NADE_REWARD : MONEY.knife))); msg.mk = attacker.money; }
  if (fell) msg.d = dropMsg(fell);
  broadcast(room, msg);
  if (bombRoom) { dropBomb(room, victim); victim.st = null; roundCheck(room, now); return; }
  victim.st = null;
  if (room.score.ct >= (room.limit || KILL_LIMIT) || room.score.t >= (room.limit || KILL_LIMIT)) endMatch(room, now);
}
function damage(room, victim, attacker, dmg, group, ap, wid, now) {
  const armored = victim.armor > 0 && (group === 1 ? victim.helmet : group !== 4);
  if (attacker && attacker.bot) dmg *= BOT_DMG;
  if (armored && (attacker || wid === 'bomb')) { const through = dmg * ap; victim.armor = Math.max(0, victim.armor - (dmg - through) * 0.5); dmg = through; }
  dmg = Math.max(1, Math.round(dmg));
  const before = victim.hp;
  victim.hp -= dmg;
  if (attacker && attacker !== victim && attacker.team !== victim.team) { const real = Math.min(dmg, Math.max(0, before)); attacker.dmg = (attacker.dmg || 0) + real; (victim.dmgBy || (victim.dmgBy = new Map())).set(attacker.id, (victim.dmgBy.get(attacker.id) || 0) + real); }
  if (victim.bot) { if (room.host) send(room.host.c, { t: 'hurt', id: victim.id, hp: Math.max(0, victim.hp), ar: Math.round(victim.armor), k: attacker ? attacker.id : -1, g: group }); }
  else send(victim.c, { t: 'hurt', hp: Math.max(0, victim.hp), ar: Math.round(victim.armor), k: attacker ? attacker.id : -1, g: group });
  if (victim.hp <= 0) kill(room, victim, attacker, wid, group === 1 && !!attacker, now);
}
// стрелять можно не чаще, чем позволяет ствол (с небольшим запасом на задержки сети)
function allowHit(p, wid, w, now) {
  let b = p.budget[wid]; const cap = w[4] * 2 + 1;
  if (!b) b = p.budget[wid] = { n: cap, at: now };
  b.n = Math.min(cap, b.n + (now - b.at) * (w[4] / w[3]) * 1.25); b.at = now;
  if (b.n < 1) return false; b.n -= 1; return true;
}
function target(room, p, id, now) {
  if (!fighting(room) || !p.alive) return null;
  const v = room.players.get(id);
  if (!v || v === p || !v.alive || v.team === p.team || now < v.protectUntil) return null;
  return v;
}

// ---- (3.4) гранаты ---------------------------------------------------------------------------------
// Бросок ведёт игра бросившего: она сообщает, откуда и с какой скоростью граната полетела, а потом где и чем взорвалась (осколочная:
// кого достала). Сервер проверяет, что граната была, что взрыв не дальше, чем она могла долететь, и что задетые стоят рядом с местом
// взрыва; урон считает сам, по своему расстоянию. Огонь горит семь секунд и жжёт тех, кто в нём стоит; дым тушит огонь.
function throwNade(room, p, m, now) {
  const id = NADE_IDS[num(m[2], 0, 9, -1) | 0], lid = num(m[1], 0, 1e9, 0) | 0;
  if (!id || !lid || !p.alive || !fighting(room)) return;
  p.nades = p.nades || {};
  if ((p.nades[id] | 0) <= 0) return;                                  // такой гранаты у него нет: не купил или уже бросил
  const x = num(m[3], -1e5, 1e5, 0), y = num(m[4], -1e5, 1e5, 0), z = num(m[5], -1e5, 1e5, 0), vx = num(m[6], -2000, 2000, 0), vy = num(m[7], -2000, 2000, 0), vz = num(m[8], -2000, 2000, 0);
  if (p.st && Math.hypot(p.st[1] - x, p.st[3] - z) > 220) return;       // бросок не оттуда, где он стоит
  if (Math.hypot(vx, vy, vz) > 1300) return;
  p.nades[id]--;
  if (!room.nades) room.nades = new Map();
  const key = p.id + ':' + lid; if (room.nades.has(key)) return;
  room.nades.set(key, { p, id, kind: NADE[id].kind, x, y, z, at: now, done: false });
  if (room.nades.size > 80) room.nades.delete(room.nades.keys().next().value);
  broadcast(room, ['gr', p.id, lid, NADE_IDS.indexOf(id), x, y, z, vx, vy, vz], p);
}
function popNade(room, p, m, now) {
  const lid = num(m[1], 0, 1e9, 0) | 0, kind = NADE_POPS[num(m[2], 0, 9, -1) | 0], n = room.nades && room.nades.get(p.id + ':' + lid);
  if (!n || n.done || !kind) return;
  const x = num(m[3], -1e5, 1e5, 0), y = num(m[4], -1e5, 1e5, 0), z = num(m[5], -1e5, 1e5, 0), age = now - n.at;
  if (age < 150 || age > 9000 || Math.hypot(x - n.x, z - n.z) > 2600 || (kind !== n.kind && !(kind === 'fizz' && n.kind === 'fire'))) return;
  n.done = true;
  broadcast(room, ['gx', p.id, lid, NADE_POPS.indexOf(kind), x, y, z], p);
  if (!room.fires) room.fires = []; if (!room.smokes) room.smokes = [];
  if (kind === 'he') {
    // задетых называет бросивший (у него стены и укрытия); сервер проверяет расстояние по своим данным и считает урон
    for (let i = 6; i < m.length && i < 22; i++) {
      const v = room.players.get(num(m[i], 0, 1e9, -1) | 0); if (!v || !v.alive || !v.st || now < v.protectUntil) continue;
      if (v !== p && v.team === p.team) continue;
      const d = Math.hypot(v.st[1] - x, v.st[2] + 40 - y, v.st[3] - z); if (d > HE_R + 60) continue;
      const dmg = HE_DMG * Math.pow(Math.max(0, 1 - Math.max(0, d - 30) / HE_R), 1.5); if (dmg >= 1) damage(room, v, p, dmg, 2, HE_AP, 'he', now);
    }
  } else if (kind === 'smoke') {
    room.smokes.push({ x, y, z, until: now + SMOKE_MS });
    room.fires = room.fires.filter(f => Math.hypot(f.x - x, f.z - z) >= SMOKE_R + 30);
  } else if (kind === 'fire') {
    if (room.smokes.some(s => now < s.until && Math.hypot(s.x - x, s.z - z) < SMOKE_R && Math.abs(s.y - y) < 120)) return;
    room.fires.push({ x, y, z, p, at: now, tickAt: now + 200 });
  }
}
function tickFires(room, now) {
  room.smokes = (room.smokes || []).filter(s => now < s.until);
  room.fires = room.fires.filter(f => now - f.at < FIRE_MS);
  for (const f of room.fires) {
    if (now < f.tickAt) continue; f.tickAt = now + FIRE_TICK;
    const age = (now - f.at) / 1000, r = FIRE_R * Math.min(1, 0.45 + age * 1.6);
    room.players.forEach(v => {
      if (!v.alive || !v.st || now < v.protectUntil || !fighting(room)) return;
      if (v !== f.p && v.team === f.p.team) return;
      const dy = v.st[2] - f.y; if (Math.hypot(v.st[1] - f.x, v.st[3] - f.z) < r && dy < 70 && dy > -40) damage(room, v, f.p.alive || room.players.has(f.p.id) ? f.p : null, FIRE_DMG, 2, 1, 'fire', now);
    });
  }
}

// ---- боты командного боя ----------------------------------------------------------------------
// Бот это участник комнаты без своего соединения: где он и в кого попал, сообщает игра хозяина,
// а здоровье, счёт и возрождение ведёт сервер, как у людей.
function ableHost(p, now) { return !p.bot && p.cv >= BOT_BUILD && now - p.seen < HOST_LAG_MS; }
function botCount(room, team) { let n = 0; room.players.forEach(p => { if (p.bot && (!team || p.team === team)) n++; }); return n; }
function addBot(room, team, now) {
  const taken = {}; room.players.forEach(p => { taken[p.name] = true; });
  const free = BOT_NAMES.filter(n => !taken[n]), name = free.length ? free[Math.floor(Math.random() * free.length)] : 'Бот ' + room.nextId;
  const b = { id: room.nextId++, c: null, bot: true, name: name, team: team, grp: room.side.indexOf(team), uid: '', pid: '', party: '', cv: 0, alive: false, hp: 100, armor: 100, helmet: true,
    kills: 0, deaths: 0, st: null, act: null, respawnAt: 0, protectUntil: 0, seen: now, budget: {}, knifeAt: 0, chatAt: 0 };
  room.players.set(b.id, b);
  broadcast(room, { t: 'join', p: pub(b) });
  if (room.state === 'live') spawn(room, b, now);
}
function removeBot(room, team) {
  // уходит тот, кого меньше жалко: сначала убитый, потом с меньшим счётом
  let pick = null; room.players.forEach(p => { if (p.bot && p.team === team && (!pick || (pick.alive && !p.alive) || (pick.alive === p.alive && p.kills < pick.kills))) pick = p; });
  if (!pick) return false;
  room.players.delete(pick.id); broadcast(room, { t: 'leave', id: pick.id }); return true;
}
// кто ведёт ботов: об этом узнают все, а новому хозяину заодно сообщается здоровье каждого бота
function setHost(room, p) {
  room.host = p; const list = [];
  room.players.forEach(q => { if (q.bot) list.push([q.id, Math.max(0, q.hp), Math.round(q.armor), q.alive ? 1 : 0]); });
  broadcast(room, { t: 'host', id: p ? p.id : 0, bots: list });
  if (p) log('ботов ведёт:', p.name, '| комната', room.name);
}
// привести ботов комнаты в порядок: кто их ведёт и сколько их должно быть в каждой команде
function botRoom(room) { return BOT_TEAM > 0 && room.mode === 'tdm' && !room.ranked && (room.auto || room.name.indexOf('bs-') === 0); }      // общие комнаты боя; в своей комнате (имя выбрали сами игроки) ботов нет
function fillBots(room, now) {
  if (!botRoom(room)) return;
  let host = room.host && room.players.get(room.host.id) === room.host ? room.host : null, able = null;
  room.players.forEach(p => { if (!able && p !== host && ableHost(p, now)) able = p; });
  if (host && !ableHost(host, now) && able) host = null;            // хозяин завис, а подхватить есть кому
  if (!host) host = able;
  if (humans(room) >= 2) room.botsOn = true;                        // двое живых: дальше команды добираются ботами
  const on = BOT_TEAM > 0 && room.botsOn && !!host;
  if (host !== room.host) setHost(room, host);
  for (const team of ['ct', 't']) {
    const want = on ? Math.max(0, BOT_TEAM - humans(room, team)) : 0; let have = botCount(room, team);
    while (have > want && removeBot(room, team)) have--;
    while (have < want) { addBot(room, team, now); have++; }
  }
}
// положение бойца из сообщения: x y z, поворот, наклон, присед, оружие, флаги, скин
function stateOf(id, m) {
  return [id, Math.round(num(m[1], -1e5, 1e5, 0) * 10) / 10, Math.round(num(m[2], -1e5, 1e5, 0) * 10) / 10, Math.round(num(m[3], -1e5, 1e5, 0) * 10) / 10,
    Math.round(num(m[4], -1e4, 1e4, 0) * 1000) / 1000, Math.round(num(m[5], -1.6, 1.6, 0) * 1000) / 1000, Math.round(num(m[6], 0, 1, 0) * 100) / 100, num(m[7], 0, 99, 0) | 0, num(m[8], 0, 255, 0) | 0,
    num(m[9], 0, 999, 0) | 0];
}

// ---- пати -------------------------------------------------------------------------------------
// У каждого игрока свой код. Кто ввёл у себя чужой код, идёт за его хозяином; общий код пати
// сервер находит, пройдя по этим ссылкам (двое ввели коды друг друга: берётся меньший из двух).
const PARTY_RE = /^[A-Z0-9]{4,8}$/;
const partyLink = new Map();      // свой код -> { to: введённый чужой код или '', at: когда сообщил }
const partyMenu = new Map();      // код пати -> Map(отметка игрока -> { n: имя, at: когда отмечался в меню })
const partyWhere = new Map();     // отметка игрока -> код пати, в чьём меню он числится (перешёл в другое пати: из старого убирается сразу)
function partyOf(own, to, now) {
  if (typeof own !== 'string' || !PARTY_RE.test(own)) return '';
  to = typeof to === 'string' && PARTY_RE.test(to) && to !== own ? to : '';
  if (partyLink.has(own) || partyLink.size < 5000) partyLink.set(own, { to: to, at: now });
  let cur = own; const seen = [own];
  for (let i = 0; i < 6; i++) {
    const l = partyLink.get(cur); if (!l || !l.to || now - l.at > 600000) break;
    if (seen.indexOf(l.to) >= 0) { let m = seen[0]; for (const s of seen) if (s < m) m = s; return m; }
    cur = l.to; seen.push(cur);
  }
  return cur;
}
function joinable(r) { return !r.allow && humans(r) < r.size && !(r.ranked && r.phase !== 'wait'); }
// друг из того же пати, к которому можно зайти: выбирается комната, где людей больше
function partyMate(code, uid) {
  if (!code) return null; let best = null;
  rooms.forEach(r => { if (!joinable(r)) return; r.players.forEach(p => { if (!p.bot && p.party === code && (!uid || p.uid !== uid) && (!best || humans(r) > humans(best.room))) best = { room: r, p: p }; }); });
  return best;
}
// кто ещё в этом пати: в бою (s: 1, можно ли к нему зайти) и в меню (s: 0); заодно отмечается сам спросивший
function partyList(code, pid, name, now) {
  let m = partyMenu.get(code); if (!m && partyMenu.size < 3000) partyMenu.set(code, m = new Map());
  if (m && typeof pid === 'string' && PID_RE.test(pid) && (m.has(pid) || m.size < 12)) {
    const was = partyWhere.get(pid); if (was && was !== code) { const old = partyMenu.get(was); if (old) old.delete(pid); }
    if (partyWhere.has(pid) || partyWhere.size < 20000) partyWhere.set(pid, code);
    m.set(pid, { n: cleanName(name), at: now });
  }
  const out = [], inRoom = {};
  rooms.forEach(r => r.players.forEach(p => { if (!p.bot && p.party === code && p.pid !== pid) { inRoom[p.pid] = 1; out.push({ n: p.name, s: 1, m: r.ranked ? 'ranked' : r.mode, o: joinable(r) ? 1 : 0 }); } }));
  if (m) m.forEach((v, k) => { if (now - v.at > 45000) m.delete(k); else if (k !== pid && !inRoom[k]) out.push({ n: v.n, s: 0 }); });
  return out.slice(0, 8);
}
setInterval(() => {
  const now = Date.now();
  rooms.forEach(r => r.players.forEach(p => { const l = p.own ? partyLink.get(p.own) : null; if (l) l.at = now; }));      // кто в бою, тот в пати остаётся
  partyLink.forEach((l, k) => { if (now - l.at > 900000) partyLink.delete(k); });
  partyMenu.forEach((m, k) => { m.forEach((v, q) => { if (now - v.at > 45000) { m.delete(q); if (partyWhere.get(q) === k) partyWhere.delete(q); } }); if (!m.size) partyMenu.delete(k); });
}, 60000);

// вход без выбора комнаты: самая заполненная общая комната этого режима, где ещё есть место; если такой нет, открывается новая
function autoRoom(now, mode) {
  let best = null; const ranked = mode === 'ranked', kind = ranked ? 'bomb' : mode;
  rooms.forEach(r => {
    const n = humans(r);
    if (!r.auto || r.mode !== kind || r.ranked !== ranked || n >= r.size) return;
    if (ranked && r.phase !== 'wait') return;                        // в начатый рейтинговый матч не подсаживают
    if (!best || n > humans(best)) best = r;
  });
  if (best) return best;
  if (rooms.size >= MAX_ROOMS) return null;
  const prefix = ranked ? 'rank-' : (kind === 'bomb' ? 'bomb-' : 'arena-');
  // (3.4) a new shared room opens on the map whose turn it is: they take turns every 20 minutes, the same for everyone
  const turn = Math.floor(now / MAP_TURN_MS), map = kind === 'bomb' ? BOMB_MAPS[turn % BOMB_MAPS.length] : ['town', 'oasis'][turn % 2];
  for (let i = 1; ; i++) if (!rooms.has(prefix + i)) { const r = newRoom(prefix + i, now, kind, map, ranked); r.auto = true; return r; }
}
// «Сейчас играют» в меню игры: общие бои, где есть люди и есть место (свои комнаты и рейтинговые матчи сюда не попадают)
function liveList() {
  const list = [];
  rooms.forEach(r => {
    const n = humans(r); if (!n || r.ranked || !joinable(r) || !(r.auto || r.name.indexOf('bs-') === 0)) return;
    const names = []; r.players.forEach(p => { if (!p.bot && names.length < 3) names.push(p.name); });
    list.push({ room: r.name, n: n, bots: botCount(r), max: r.size, mode: r.mode, map: r.map, names: names });
  });
  list.sort((a, b) => b.n - a.n);
  return list.slice(0, 3);
}
// комнаты, где сейчас играют: сначала самые людные
function roomList(now) {
  const list = [];
  rooms.forEach(r => {
    const names = []; let bots = 0; r.players.forEach(p => { if (p.bot) bots++; else names.push(p.name); });
    const bombRoom = r.mode === 'bomb';
    list.push({ room: r.name, n: names.length, bots: bots, max: r.size, s: bombRoom ? r.wins : [r.score.ct, r.score.t], state: r.state, left: Math.max(0, r.endsAt - now), names: names,
      mode: r.mode, map: r.map, ranked: r.ranked ? 1 : 0, open: r.ranked && r.phase !== 'wait' ? 0 : 1 });
  });
  list.sort((a, b) => b.n - a.n);
  return list.slice(0, 12);
}
function onJoin(c, m, now) {
  if (m.v !== VERSION || !((m.cv | 0) >= MIN_BUILD)) { refuse(c, 'version'); return; }      // у старой игры другая карта: ей нужно обновление
  const uid = typeof m.uid === 'string' && UID_RE.test(m.uid) ? m.uid : '';
  if (banned(uid, now)) { refuse(c, 'ban'); return; }                 // (3.5) админ закрыл этому игроку онлайн
  if (m.watch) { onWatch(c, m, now, uid); return; }                   // (3.6) зритель: смотрит, не играя
  const mode = m.mode === 'ranked' ? 'ranked' : (m.mode === 'bomb' ? 'bomb' : 'tdm');
  const eco = (m.cv | 0) >= ECO_BUILD;          // игра до 3.1 не умеет покупать через сервер: в раунды с бомбой её не пускают, ей нужно обновление
  if (!eco && mode !== 'tdm') { refuse(c, 'version'); return; }
  const wanted = String(m.room == null ? '' : m.room).trim(); let room;
  const party = partyOf(m.own, m.party, now), mate = partyMate(party, uid);
  if (mate && (uid || !mate.room.ranked)) room = mate.room;          // друг из пати уже в комнате: туда же, какую бы комнату ни просили
  else if (mode === 'ranked' || !wanted || wanted === 'auto') {
    if (mode === 'ranked' && !uid) { refuse(c, 'version'); return; }
    room = autoRoom(now, mode); if (!room) { refuse(c, 'rooms'); return; }
  } else {
    const roomName = cleanRoom(wanted); room = rooms.get(roomName);
    if (room && room.allow) { if (!room.allow.has(uid)) { refuse(c, 'lobby'); return; } }          // (3.5) матч лобби: только те, кого позвали
    else {
      if (!room) { if (rooms.size >= MAX_ROOMS) { refuse(c, 'rooms'); return; } room = newRoom(roomName, now, mode, m.map, false); }
      if (!joinable(room)) { refuse(c, 'full'); return; }
    }
  }
  if (!eco && room.mode === 'bomb') { refuse(c, 'version'); return; }          // (комната друга из пати или комната по имени)
  let ct = 0, t = 0; const taken = {};
  room.players.forEach(p => { taken[p.name] = true; if (p.bot) return; if (p.team === 'ct') ct++; else t++; });      // команды равняются по людям: боты подстроятся
  const side = room.ranked ? 2 : Math.ceil(room.size / 2);
  const team = room.allow ? room.side[room.allow.get(uid) ? 1 : 0] : (mate && mate.room === room && humans(room, mate.p.team) < side ? mate.p.team : (ct === t ? (m.team === 't' ? 't' : 'ct') : (ct < t ? 'ct' : 't')));
  let name = cleanName(m.name); for (let i = 2; taken[name]; i++) name = cleanName(m.name).slice(0, 11) + ' ' + i;
  const p = { id: room.nextId++, c: c, name: name, team: team, grp: room.side.indexOf(team), uid: uid, pid: typeof m.pid === 'string' && PID_RE.test(m.pid) ? m.pid : '', party: party, own: party && typeof m.own === 'string' ? m.own : '', cv: m.cv | 0, admin: isAdmin(m.tok), extra: null, alive: false, hp: 100, armor: 100, helmet: true, kills: 0, deaths: 0, st: null, act: null, respawnAt: 0, protectUntil: 0, seen: now, budget: {}, knifeAt: 0, chatAt: 0 };
  p.money = MONEY.start; p.gun = { primary: '', secondary: DEFAULT_PISTOL[team] }; p.kev = 0; p.helm = false; p.fresh = true;      // (раунды с бомбой: деньги и снаряжение)
  p.clan = uid ? clanTagOf(uid) : null; p.ping = -1;      // (3.3) тег клана для таблицы боя; пинг, как его меряет сама игра
  c.p = p; c.room = room; room.players.set(p.id, p);
  if (uid && room.ranked) rating(uid, name);
  const bombRoom = room.mode === 'bomb';
  send(c, Object.assign(roomState(room, now), { t: 'welcome', id: p.id, name: p.name, team: team, rating: uid && ratings[uid] ? ratings[uid].r : 1000,
    mate: mate && mate.room === room ? mate.p.id : 0, adm: p.admin ? 1 : 0, admchk: 1, kit: bombRoom ? kitMsg(p) : null }));
  broadcast(room, { t: 'join', p: pub(p) }, p);
  if (party) room.players.forEach(q => { if (q !== p && q.c && q.party === party) send(q.c, { t: 'mate', id: p.id }); });      // друзьям из пати: свой зашёл
  log('вход:', p.name, '| комната', room.name, '| игроков', humans(room), mate && mate.room === room ? '| к другу из пати' : '');
  if (!bombRoom && room.state === 'live') spawn(room, p, now);       // в комнате с бомбой новичок выходит со следующего раунда
  fillBots(room, now);
  if (room.lobby) { const L = lobbies.get(room.lobby); if (L) lbPush(L); }          // (3.6) в лобби видно, кто уже в матче
}

function onText(c, text) {
  const now = Date.now();
  if (now - c.rlAt > 1000) { c.rlAt = now; c.rl = 0; }
  if (++c.rl > 720) { drop(c, 'flood'); return; }      // (игра, которая ведёт девять ботов, сообщает и их выстрелы с попаданиями)
  let m; try { m = JSON.parse(text); } catch (e) { return; }
  const p = c.p, room = c.room;
  if (!Array.isArray(m)) {
    if (m && m.t === 'join' && !p && !c.w) onJoin(c, m, now);
    else if (m && m.t === 'rooms') { c.at = now; send(c, { t: 'rooms', list: roomList(now) }); }      // кто сейчас играет: для списка комнат в игре
    else if (m && m.t === 'on') {      // счётчик онлайна для главного меню; заодно игра узнаёт свой рейтинг
      c.at = now; mark(m.p, now); const o = onlineCount(now), ou = typeof m.uid === 'string' && UID_RE.test(m.uid) ? m.uid : '', mine = ou ? ratings[ou] : null;
      const ck = ou && clanOf[ou] ? clans[clanOf[ou]] : null; if (ck) ck.m[ou].s = now;      // (3.3) участник клана в сети
      const party = partyOf(m.own, m.party, now);
      if (ou && accs[ou]) accs[ou].seen = now;
      send(c, { t: 'on', ann: ANN.until > now ? [ANN.id, ANN.text] : null, n: o.n, playing: o.playing, rooms: rooms.size, modes: o.modes, wait: o.wait, fights: o.fights, peak: o.peak, r: mine ? mine.r : 1000, g: mine ? mine.g : 0, pc: party, pm: party ? partyList(party, m.p, m.name, now) : [], cl: ck ? { tag: ck.tag, name: ck.name, col: ck.col } : null, live: liveList(), fr: frBrief(ou, now) });
    }
    else if (m && m.t === 'code' && typeof m.code === 'string') { c.at = now; onCode(c, m, now); }
    else if (m && m.t === 'adm') { c.at = now; onAdm(c, m, now); }
    else if (m && m.t === 'clan') { c.at = now; onClan(c, m, now); }
    else if (m && m.t === 'acc') { c.at = now; onAcc(c, m, now); }          // (3.5) аккаунт: голда, скины, ножи, уведомления
    else if (m && m.t === 'mk') { c.at = now; onMarket(c, m, now); }        // (3.5) рынок
    else if (m && m.t === 'lb') { onLobby(c, m, now); }                     // (3.5) лобби
    else if (m && m.t === 'fr') { onFriends(c, m, now); }                   // (3.6) друзья
    else if (m && m.t === 'hi') { c.at = now; }                             // (3.5) открытая админ-панель: соединение живо
    else if (m && m.t === 'top') { c.at = now; if (now - (c.topAt || 0) > 900) { c.topAt = now; send(c, topList(typeof m.uid === 'string' && UID_RE.test(m.uid) ? m.uid : '')); } }
    return;
  }
  if (c.w) { if (m[0] === 'p') { c.at = now; send(c, ['p', num(m[1], 0, 1e15, 0)]); } return; }          // (3.6) зритель: только пинг
  if (!p || !room) return;
  p.seen = now;
  switch (m[0]) {
    case 's':                                             // моё положение: x y z, поворот, наклон, присед, оружие, флаги
      if (!p.alive) return;
      p.st = stateOf(p.id, m);                             // (последнее число: какой скин на оружии, чтобы его видели все)
      if (!p.admin) p.st[8] &= 7;                          // перчатки админа (старшие биты флагов) есть только у админа
      return;
    // ---- хозяин ботов сообщает за них: положение, выстрел, попадание, удар ножом, падение ----
    case 'S':
      if (room.host !== p || !Array.isArray(m[1])) return;
      for (const e of m[1].slice(0, 16)) { const b = Array.isArray(e) ? room.players.get(e[0]) : null; if (b && b.bot && b.alive) { b.st = stateOf(b.id, e); b.st[8] &= 7; } }
      return;
    case 'F': {
      const b = room.players.get(m[1]); if (room.host !== p || !b || !b.bot || !b.alive || !fighting(room)) return;
      broadcast(room, ['f', b.id, num(m[2], 0, 99, 0) | 0, Math.round(num(m[3], -1e5, 1e5, 0)), Math.round(num(m[4], -1e5, 1e5, 0)), Math.round(num(m[5], -1e5, 1e5, 0)), m[6] ? 1 : 0], p);
      return;
    }
    case 'H': {
      const b = room.players.get(m[1]); if (room.host !== p || !b || !b.bot) return;
      const wid = typeof m[3] === 'string' ? m[3] : '', w = Object.prototype.hasOwnProperty.call(WEAPONS, wid) ? WEAPONS[wid] : null, v = target(room, b, m[2], now);
      const group = num(m[4], 1, 4, 2) | 0;
      if (!w || !v || (SIDE[wid] && SIDE[wid] !== b.team) || !allowHit(b, wid, w, now)) return;
      damage(room, v, b, w[0] * Math.pow(w[1], num(m[5], 0, 8192, 0) / 500) * HIT_MULT[group], group, w[2], wid, now);
      return;
    }
    case 'K': {
      const b = room.players.get(m[1]); if (room.host !== p || !b || !b.bot) return;
      const v = target(room, b, m[2], now), kind = num(m[3], 0, 3, 0) | 0;
      if (!v || now - b.knifeAt < 350) return;
      if (b.st && v.st && Math.hypot(b.st[1] - v.st[1], b.st[2] - v.st[2], b.st[3] - v.st[3]) > 260) return;
      b.knifeAt = now;
      damage(room, v, b, KNIFE_DMG[kind], 2, KNIFE_AP, typeof m[4] === 'string' ? m[4].slice(0, 16) : 'knife_ct', now);
      return;
    }
    case 'D': {
      const b = room.players.get(m[1]); if (room.host !== p || !b || !b.bot || !b.alive || !fighting(room)) return;
      damage(room, b, null, num(m[2], 1, 1000, 1), 4, 1, 'fall', now);
      return;
    }
    case 'g':                                             // одиночка просит начать бой с ботами, не дожидаясь второго игрока
      if (botRoom(room) && p.cv >= BOT_BUILD && !room.botsOn) { room.botsOn = true; fillBots(room, now); log('бой с ботами начат | комната', room.name, '| просил', p.name); }
      return;
    case 'c': {                                           // чат: 0 всем в комнате, 1 только своей команде
      const text = cleanChat(m[2]);
      if (!text || now - p.chatAt < 500) return;
      p.chatAt = now;
      const scope = m[1] ? 1 : 0, buf = frame(JSON.stringify(['c', p.id, scope, text]));
      room.players.forEach(q => { if (q.c && (!scope || q.team === p.team)) sendRaw(q.c, buf); });
      if (!scope && room.watch) room.watch.forEach(w => sendRaw(w, buf));
      return;
    }
    case 'f':                                             // выстрел или взмах ножом: показать остальным
      if (!p.alive || !fighting(room)) return;
      broadcast(room, ['f', p.id, num(m[1], 0, 99, 0) | 0, Math.round(num(m[2], -1e5, 1e5, 0)), Math.round(num(m[3], -1e5, 1e5, 0)), Math.round(num(m[4], -1e5, 1e5, 0)), m[5] ? 1 : 0], p);
      return;
    case 'h': {                                           // попадание пулей: в кого, из чего, куда, с какого расстояния
      const wid = typeof m[2] === 'string' ? m[2] : '', w = Object.prototype.hasOwnProperty.call(WEAPONS, wid) ? WEAPONS[wid] : null, v = target(room, p, m[1], now);
      const group = num(m[3], 1, 4, 2) | 0;
      if (!w || !v || (SIDE[wid] && SIDE[wid] !== p.team && !(p.extra && p.extra[wid])) || !ownsGun(room, p, wid) || !allowHit(p, wid, w, now)) return;      // чужой стороны ствол урона не наносит, если он не подобран с земли; в раундах с бомбой только свой
      damage(room, v, p, w[0] * Math.pow(w[1], num(m[4], 0, 8192, 0) / 500) * HIT_MULT[group], group, w[2], wid, now);
      return;
    }
    case 'k': {                                           // удар ножом
      const v = target(room, p, m[1], now), kind = num(m[2], 0, 3, 0) | 0;
      if (!v || now - p.knifeAt < 350) return;
      if (p.st && v.st && Math.hypot(p.st[1] - v.st[1], p.st[2] - v.st[2], p.st[3] - v.st[3]) > 260) return;      // слишком далеко для ножа
      p.knifeAt = now;
      damage(room, v, p, KNIFE_DMG[kind], 2, KNIFE_AP, typeof m[3] === 'string' ? m[3].slice(0, 16) : 'knife_ct', now);
      return;
    }
    case 'd':                                             // урон самому себе: падение с высоты или за край карты
      if (!p.alive || !fighting(room)) return;
      damage(room, p, null, num(m[1], 1, 1000, 1), 4, 1, 'fall', now);
      return;
    case 'u': {                                           // подобрать оружие с земли: его номер; что игрок бросает взамен (место в списке оружия или -1) и скин на нём
      const id = num(m[1], 0, 1e9, 0) | 0, d = room.drops.get(id);
      if (!d || now - d.at > dropLife(room)) { if (d) room.drops.delete(id); send(c, { t: 'pick', d: id, id: 0 }); return; }      // его уже нет: игра спросившего убирает его у себя
      if (!p.alive || !p.st || Math.hypot(p.st[1] - d.x, p.st[3] - d.z) > 230 || Math.abs(p.st[2] - d.y) > 130) return;      // далеко: не дотянуться
      room.drops.delete(id);
      const wid = W_IDS[d.w], ow = num(m[2], -1, 99, -1) | 0, oid = ow >= 0 ? W_IDS[ow] : null; let fell = null;
      // взамен падает то, что было у него в этом месте: только оружие, которое он и вправду мог носить (своей стороны или тоже подобранное)
      const had = oid && (room.mode === 'bomb' ? ownsGun(room, p, oid) : (!SIDE[oid] || SIDE[oid] === p.team || (p.extra && p.extra[oid])));      // (в раундах с деньгами: только своё)
      if (had) { if (p.extra && oid !== wid) delete p.extra[oid]; if (p.gun.primary === oid) p.gun.primary = ''; else if (p.gun.secondary === oid) p.gun.secondary = ''; fell = addDrop(room, ow, num(m[3], 0, 999, 0) | 0, p.st, now); }
      if (!p.extra) p.extra = {};
      p.extra[wid] = 1;                                    // с этой минуты и до смерти ствол его: урон из него засчитывается, чьей бы стороны он ни был
      if (PRICE[wid]) p.gun[PISTOLS[wid] ? 'secondary' : 'primary'] = wid;      // (и раунд пережившему он останется)
      broadcast(room, { t: 'pick', d: id, id: p.id, n: fell ? dropMsg(fell) : null });
      return;
    }
    case 't': {                                           // выбросить оружие из рук (например, для друга): какое (место в списке) и скин на нём
      const ow = num(m[1], -1, 99, -1) | 0, oid = ow >= 0 ? W_IDS[ow] : null;
      if (!p.alive || !p.st || !oid || now - (p.throwAt || 0) < 400) return;
      if (room.mode === 'bomb' ? !ownsGun(room, p, oid) : (SIDE[oid] && SIDE[oid] !== p.team && !(p.extra && p.extra[oid]))) return;      // только то, что он и вправду мог носить (в раундах с деньгами: своё)
      p.throwAt = now; if (p.extra) delete p.extra[oid];
      if (p.gun.primary === oid) p.gun.primary = ''; else if (p.gun.secondary === oid) p.gun.secondary = '';
      const fell = addDrop(room, ow, num(m[2], 0, 999, 0) | 0, p.st, now);
      if (fell) broadcast(room, { t: 'pick', d: 0, id: p.id, n: dropMsg(fell) });      // (то же сообщение, что при подборе: никто ничего не взял, но на земле новое оружие)
      return;
    }
    case 'gr': throwNade(room, p, m, now); return;             // (3.4) граната брошена: откуда и как быстро
    case 'gx': popNade(room, p, m, now); return;               // (3.4) граната взорвалась: где, чем, кого задела
    case 'B': buy(room, p, m[1], now); return;                // покупка в раунде с бомбой: место ствола в списке или 'vest' / 'vesthelm'
    case 'b': bombAct(room, p, m[1] === 'p' ? 'p' : (m[1] === 'd' ? 'd' : 'x'), now); return;      // бомба: начать закладку, начать разминирование, бросить
    case 'p': send(c, ['p', num(m[1], 0, 1e15, 0)]); if (m[2] != null) p.ping = num(m[2], 0, 9999, 0) | 0; return;      // проверка задержки; игра 3.3 говорит и свой пинг
  }
}

setInterval(() => {
  const now = Date.now();
  conns.forEach(c => { if (c.w) { if (now - c.at > WATCH_IDLE) drop(c, 'тишина'); } else if (!c.p && now - c.at > 10000) drop(c, 'нет входа'); });
  rooms.forEach(room => {
    room.tick++;
    room.players.forEach(p => { if (!p.bot && now - p.seen > IDLE_MS) drop(p.c, 'тишина'); });
    if (!room.players.size) return;
    if (now - room.botAt >= 1000) { room.botAt = now; fillBots(room, now); room.drops.forEach((d, id) => { if (now - d.at > dropLife(room)) room.drops.delete(id); }); }      // раз в секунду: не завис ли хозяин ботов, хватает ли их; не залежалось ли оружие на земле
    if (room.fires && room.fires.length) tickFires(room, now);
    if (room.mode === 'bomb') tickBomb(room, now);
    else if (room.state === 'live') {
      room.players.forEach(p => { if (!p.alive && p.respawnAt && now >= p.respawnAt) spawn(room, p, now); });
      if (now >= room.endsAt) endMatch(room, now);
    } else if (now >= room.postUntil && !room.allow) startMatch(room, now);
    const list = []; room.players.forEach(p => { if (p.alive && p.st) list.push(p.st); });
    if (list.length || room.tick % 10 === 0) broadcast(room, ['S', now, list]);
    if (room.tick % 6 === 0) sendHp(room);          // (3.6) здоровье: зрителям и тем, кто смотрит глазами своих
  });
}, TICK_MS);
setInterval(saveRatings, 20000);
// (3.3) пинг каждого человека в комнате, для таблицы боя: раз в две секунды всем в комнате
setInterval(() => { rooms.forEach(room => { const l = [], st = []; room.players.forEach(p => { if (!p.bot && p.ping >= 0) l.push(p.id, p.ping); st.push(p.id, p.kills | 0, p.deaths | 0, p.assists | 0, Math.round(p.dmg || 0), p.mvps | 0, p.hs | 0); }); if (l.length) broadcast(room, { t: 'pg', l: l }); if (st.length) broadcast(room, { t: 'st', l: st }); }); }, 2000);
setInterval(() => { onlineCount(Date.now()); }, 5000);          // (3.2) рекорд дня считается и тогда, когда меню ни у кого не открыто

// ===================================================================================================
// (3.5) Аккаунты на сервере, рынок скинов, лобби для турниров, админ-панель по ссылке
// ===================================================================================================

// ---- каталог: скины, кейсы, ножи. Файл catalog.json лежит рядом с server.js, его пишет сборка игры ----
// В нём то же, что знает игра: какие скины есть, что лежит в каждом кейсе и с каким шансом, сколько стоит нож.
// Без него кейсы, рынок и выдача скинов не работают (бой работает).
let CAT = null;
const CSKIN = Object.create(null), CCASE = Object.create(null), CKNIFE = Object.create(null);
try {
  const c = JSON.parse(fs.readFileSync(path.join(__dirname, 'catalog.json'), 'utf8'));
  if (!c || !Array.isArray(c.skins) || !Array.isArray(c.cases) || !Array.isArray(c.rar)) throw new Error('не тот формат');
  for (const s of c.skins) if (s && typeof s.id === 'string') CSKIN[s.id] = s;
  for (const k of c.cases) if (k && typeof k.id === 'string') CCASE[k.id] = k;
  for (const id of Object.keys(c.knives || {})) CKNIFE[id] = c.knives[id];
  CAT = c;
} catch (e) { log('catalog.json не прочитан (' + (e && e.message) + '): кейсы, рынок и выдача скинов не работают'); }
function skinName(id) { const s = CSKIN[id]; if (!s) return String(id); const w = CAT && CAT.weapons && CAT.weapons[s.w]; return (w || s.w) + ' | ' + s.n; }
// кейс открывается здесь, а не в игре: тот же расчёт, что был в игре (сначала редкость по весам, потом скин этой редкости),
// но со случайными числами сервера
function rollCaseSrv(cs) {
  const tiers = []; let total = 0;
  for (let i = 1; i < CAT.rar.length; i++) { const items = cs.items.filter(k => CSKIN[k] && CSKIN[k].r === i); if (items.length) { tiers.push({ items: items, w: CAT.rar[i].w }); total += CAT.rar[i].w; } }
  let x = crypto.randomInt(0, 1000000000) / 1000000000 * total;
  for (const t of tiers) { if (x < t.w) return t.items[crypto.randomInt(0, t.items.length)]; x -= t.w; }
  return tiers[0].items[0];
}

// ---- аккаунты: голда, скины и ножи игрока хранятся здесь (accounts.json рядом с рейтингом) ----
// Ключ — тот же секретный номер игры (uid), что и у рейтинга; всем виден только короткий ID из шести цифр.
// До 3.5 всё лежало в самой игре: при первом входе 3.5 игра присылает, что у неё есть. Голды сервер верит не больше,
// чем игрок получил по кодам (плюс немного), а скины переносит все; на рынок их можно выставить, только если их не больше,
// чем кейсов можно было открыть на эту голду.
const ACC_FILE = process.env.ACCOUNTS || path.join(path.dirname(RATE_FILE), 'accounts.json');
const accs = Object.create(null), accIds = new Map();
function accObj(v) { const o = Object.create(null); if (v && typeof v === 'object') for (const k of Object.keys(v)) if (/^[a-z0-9_]{2,40}$/.test(k)) o[k] = v[k] ? 1 : 0; return o; }
function normAcc(a) {
  return { id: a.id | 0, n: cleanName(a.n) || 'Игрок', g: Math.max(0, Math.floor(+a.g || 0)), s: accObj(a.s), k: accObj(a.k), made: +a.made || 0, seen: +a.seen || 0,
    ban: +a.ban || 0, bw: String(a.bw || '').slice(0, 120), adm: a.adm ? 1 : 0, admG: a.admG ? 1 : 0, op: a.op | 0, ns: a.ns | 0,
    nt: Array.isArray(a.nt) ? a.nt.filter(n => n && typeof n === 'object').slice(-30) : [], log: Array.isArray(a.log) ? a.log.filter(Array.isArray).slice(-40) : [],
    fr: accTimes(a.fr), fi: accTimes(a.fi), fo: accTimes(a.fo) };          // (3.6) друзья, заявки мне, мои заявки
}
try {
  const raw = JSON.parse(fs.readFileSync(ACC_FILE, 'utf8'));
  for (const u of Object.keys(raw || {})) { const a = raw[u]; if (!UID_RE.test(u) || !a || !(a.id >= 100000)) continue; accs[u] = normAcc(a); accIds.set(accs[u].id, u); }
} catch (e) { /* аккаунтов ещё нет */ }
let accDirty = false, accTm = null;
function accFlush() {
  if (!accDirty) return; accDirty = false;
  try { fs.writeFileSync(ACC_FILE + '.tmp', JSON.stringify(accs)); fs.renameSync(ACC_FILE + '.tmp', ACC_FILE); } catch (e) { log('аккаунты не сохранились:', e && e.message); }
}
function accSave() { accDirty = true; if (!accTm) accTm = setTimeout(() => { accTm = null; accFlush(); }, 1500); }
function newAccId() { for (;;) { const id = crypto.randomInt(100000, 1000000); if (!accIds.has(id)) return id; } }
function accLog(a, text) { a.log.push([Date.now(), String(text).slice(0, 140)]); if (a.log.length > 40) a.log.splice(0, a.log.length - 40); }
function accNote(a, n) { n.i = ++a.ns; n.at = Date.now(); a.nt.push(n); if (a.nt.length > 30) a.nt.splice(0, a.nt.length - 30); }
function credited(uid) {
  let g = 0;
  for (const k of Object.keys(codes.one)) if (codes.one[k].u === uid) g += codes.one[k].g;
  for (const k of Object.keys(codes.promo)) if (codes.promo[k].u[uid]) g += codes.promo[k].g;
  return g;
}
function accMake(uid, name, snap, now) {
  const a = normAcc({ id: newAccId(), n: name, made: now, seen: now });
  if (snap && typeof snap === 'object') {
    const cr = credited(uid); a.g = Math.min(Math.max(0, Math.floor(+snap.g || 0)), cr + 300);
    const skins = Array.isArray(snap.s) ? snap.s.filter(id => typeof id === 'string' && CSKIN[id]).slice(0, 400) : [];
    const cases = Math.floor(Math.max(0, cr - a.g) / 100) + 1, tr = skins.length <= cases ? 1 : 0;          // (кейс стоит 100: скинов не больше, чем кейсов на потраченную голду)
    for (const id of skins) a.s[id] = tr;
    if (Array.isArray(snap.k)) for (const id of snap.k.slice(0, 40)) if (typeof id === 'string' && CKNIFE[id] && CKNIFE[id].price) a.k[id] = 1;
    accLog(a, 'перенос из игры: голда ' + a.g + ' (в игре было ' + Math.floor(+snap.g || 0) + ', по кодам ' + cr + '), скинов ' + skins.length + (tr ? '' : ' (их нельзя продать)'));
  } else accLog(a, 'новый аккаунт');
  accs[uid] = a; accIds.set(a.id, uid); accSave();
  log('новый аккаунт', a.id, '|', a.n);
  return a;
}
function lotsOf(uid) { let n = 0; market.lots.forEach(l => { if (l.u === uid) n++; }); return n; }
function accView(a, uid, now) {
  return { id: a.id, g: a.g, s: a.s, k: Object.keys(a.k), adm: a.adm, ban: a.ban > now ? a.ban : 0, bw: a.ban > now ? a.bw : '', nt: a.nt, lots: lotsOf(uid) };
}
function banned(uid, now) { const a = uid && accs[uid]; return !!a && a.ban > now; }
// игра 3.5 спрашивает свой аккаунт, открывает кейс, покупает нож, отмечает прочитанные уведомления
function onAcc(c, m, now) {
  const uid = typeof m.uid === 'string' && UID_RE.test(m.uid) ? m.uid : '', out = o => send(c, Object.assign({ t: 'acc', op: String(m.op || '') }, o));
  if (!uid) { out({ ok: 0, msg: 'Обнови игру' }); return; }
  if (!CAT) { out({ ok: 0, msg: 'На сервере нет каталога скинов: сервер нужно обновить' }); return; }
  let a = accs[uid];
  if (m.op === 'get') {
    if (!a) a = accMake(uid, m.n, m.snap, now);
    const nm = cleanName(m.n); if (nm) a.n = nm; a.seen = now;
    if (m.tok && isAdmin(m.tok)) { a.adm = 1; if (!a.admG) { a.admG = 1; a.g += 50000; accLog(a, 'админ: +50000 голды'); } }
    accSave(); out({ ok: 1, a: accView(a, uid, now) }); return;
  }
  if (!a) { out({ ok: 0, msg: 'Аккаунт ещё не создан: открой меню игры с интернетом' }); return; }
  a.seen = now;
  if (m.op === 'ack') {
    const ids = Array.isArray(m.ids) ? m.ids.slice(0, 40).map(x => x | 0) : [];
    a.nt = a.nt.filter(n => ids.indexOf(n.i) < 0); accSave(); out({ ok: 1, a: accView(a, uid, now) }); return;
  }
  if (m.op === 'case') {
    const cs = typeof m.cs === 'string' ? CCASE[m.cs] : null; if (!cs) { out({ ok: 0, msg: 'Такого кейса нет' }); return; }
    if (now - (a.caseAt || 0) < 300) { out({ ok: 0, msg: 'Подожди секунду' }); return; }
    if (a.g < cs.price) { out({ ok: 0, msg: 'Не хватает голды', a: accView(a, uid, now) }); return; }
    a.caseAt = now; a.g -= cs.price; a.op++;
    const id = rollCaseSrv(cs), s = CSKIN[id], dup = !!(a.adm || id in a.s), refund = dup ? (CAT.rar[s.r].dup | 0) : 0;
    if (dup) a.g += refund; else a.s[id] = 1;
    accLog(a, 'кейс «' + cs.n + '»: ' + skinName(id) + (dup ? ' (повтор, вернулось ' + refund + ')' : ''));
    accSave(); out({ ok: 1, skin: id, dup: dup ? 1 : 0, refund: refund, a: accView(a, uid, now) }); return;
  }
  if (m.op === 'knife') {
    const k = typeof m.k === 'string' ? CKNIFE[m.k] : null; if (!k || !(k.price > 0)) { out({ ok: 0, msg: 'Этот нож не продаётся' }); return; }
    if (a.k[m.k] || a.adm) { out({ ok: 1, a: accView(a, uid, now) }); return; }
    if (a.g < k.price) { out({ ok: 0, msg: 'Не хватает голды', a: accView(a, uid, now) }); return; }
    a.g -= k.price; a.k[m.k] = 1; accLog(a, 'нож «' + k.n + '» за ' + k.price);
    accSave(); out({ ok: 1, a: accView(a, uid, now) }); return;
  }
  out({ ok: 0, msg: 'Обнови игру' });
}

// ---- рынок: игроки продают друг другу скины за голду (market.json рядом с рейтингом) ----
// Выставленный скин уходит из аккаунта продавца и лежит на рынке; купили — скин у покупателя, голда минус 10% у продавца;
// сняли или прошло 14 дней — скин возвращается. Продать можно только скин, полученный через сервер (кейс, рынок, подарок).
const MK_FILE = process.env.MARKET || path.join(path.dirname(RATE_FILE), 'market.json');
const MK_FEE = 0.1, MK_MAX = 10, MK_DAYS = 14, MK_PRICE = 500000, MK_TOTAL = 4000;
const market = { seq: 1, lots: new Map(), hist: [] };
try {
  const raw = JSON.parse(fs.readFileSync(MK_FILE, 'utf8'));
  if (raw && Array.isArray(raw.lots)) for (const l of raw.lots) if (l && l.id > 0 && UID_RE.test(l.u) && typeof l.s === 'string' && l.p > 0) market.lots.set(l.id | 0, { id: l.id | 0, u: l.u, sid: l.sid | 0, n: cleanName(l.n) || 'Игрок', s: l.s, p: l.p | 0, at: +l.at || 0 });
  if (raw && Array.isArray(raw.hist)) market.hist = raw.hist.filter(h => h && typeof h.s === 'string').slice(-300);
  market.seq = Math.max(raw && raw.seq | 0, 1); market.lots.forEach(l => { if (l.id >= market.seq) market.seq = l.id + 1; });
} catch (e) { /* рынок ещё пуст */ }
let mkTm = null;
function mkSave() {
  if (mkTm) return;
  mkTm = setTimeout(() => {
    mkTm = null; const lots = []; market.lots.forEach(l => lots.push(l));
    try { fs.writeFileSync(MK_FILE + '.tmp', JSON.stringify({ seq: market.seq, lots: lots, hist: market.hist })); fs.renameSync(MK_FILE + '.tmp', MK_FILE); } catch (e) { log('рынок не сохранился:', e && e.message); }
  }, 1500);
}
function mkFlushNow() { if (mkTm) { clearTimeout(mkTm); mkTm = null; const lots = []; market.lots.forEach(l => lots.push(l)); try { fs.writeFileSync(MK_FILE, JSON.stringify({ seq: market.seq, lots: lots, hist: market.hist })); } catch (e) { /* выходим всё равно */ } } }
// цена последних продаж скина: для подсказки продавцу и покупателю
function mkLast(now) {
  const last = Object.create(null);
  for (const h of market.hist) { if (now - h.at > 30 * 864e5) continue; const v = last[h.s] || (last[h.s] = [0, 0]); v[0] = h.p; v[1]++; }
  return last;
}
// лот уходит с рынка обратно к продавцу (снял сам, прошёл срок, убрал админ)
function mkReturn(l, why, now) {
  market.lots.delete(l.id);
  const a = accs[l.u]; if (a) { a.s[l.s] = 1; accLog(a, 'лот снят (' + why + '): ' + skinName(l.s)); if (why !== 'сам') accNote(a, { k: 'back', s: l.s, why: why }); accSave(); }
  mkSave();
}
function onMarket(c, m, now) {
  const uid = typeof m.uid === 'string' && UID_RE.test(m.uid) ? m.uid : '', out = o => send(c, Object.assign({ t: 'mk', op: String(m.op || '') }, o));
  if (!CAT) { out({ ok: 0, msg: 'На сервере нет каталога скинов: сервер нужно обновить' }); return; }
  if (m.op === 'list') {
    const sum = Object.create(null);
    market.lots.forEach(l => { const v = sum[l.s] || (sum[l.s] = [l.s, 0, l.p]); v[1]++; if (l.p < v[2]) v[2] = l.p; });
    out({ ok: 1, sum: Object.keys(sum).map(k => sum[k]), last: mkLast(now), fee: MK_FEE }); return;
  }
  if (m.op === 'lots') {
    const s = String(m.s || ''), list = []; market.lots.forEach(l => { if (l.s === s) list.push(l); });
    list.sort((x, y) => x.p - y.p || x.at - y.at);
    out({ ok: 1, s: s, lots: list.slice(0, 40).map(l => [l.id, l.p, l.n, l.at, l.u === uid ? 1 : 0]), last: mkLast(now)[s] || null }); return;
  }
  const a = uid ? accs[uid] : null; if (!a) { out({ ok: 0, msg: 'Рынок работает после входа в аккаунт: открой меню игры с интернетом' }); return; }
  a.seen = now;
  if (m.op === 'mine') { const list = []; market.lots.forEach(l => { if (l.u === uid) list.push([l.id, l.s, l.p, l.at]); }); out({ ok: 1, lots: list, a: accView(a, uid, now) }); return; }
  if (a.ban > now) { out({ ok: 0, msg: 'Доступ к рынку закрыт' + (a.bw ? ': ' + a.bw : '') }); return; }
  if (now - (a.mkAt || 0) < 400) { out({ ok: 0, msg: 'Подожди секунду' }); return; }
  a.mkAt = now;
  if (m.op === 'sell') {
    const s = String(m.s || ''), p = Math.floor(num(m.p, 0, MK_PRICE, 0));
    if (!CSKIN[s]) { out({ ok: 0, msg: 'Такого скина нет' }); return; }
    if (!(s in a.s) || a.adm) { out({ ok: 0, msg: 'Этого скина у тебя нет' }); return; }
    if (a.s[s] !== 1) { out({ ok: 0, msg: 'Этот скин получен до 3.5: его нельзя продать' }); return; }
    if (p < 1) { out({ ok: 0, msg: 'Цена от 1 до ' + MK_PRICE + ' голды' }); return; }
    if (lotsOf(uid) >= MK_MAX) { out({ ok: 0, msg: 'На рынке уже ' + MK_MAX + ' твоих лотов' }); return; }
    if (market.lots.size >= MK_TOTAL) { out({ ok: 0, msg: 'Рынок переполнен, попробуй позже' }); return; }
    delete a.s[s];
    const l = { id: market.seq++, u: uid, sid: a.id, n: a.n, s: s, p: p, at: now }; market.lots.set(l.id, l);
    accLog(a, 'выставил ' + skinName(s) + ' за ' + p); accSave(); mkSave();
    out({ ok: 1, lot: [l.id, l.s, l.p, l.at], a: accView(a, uid, now) }); return;
  }
  if (m.op === 'buy') {
    const l = market.lots.get(m.lot | 0);
    if (!l) { out({ ok: 0, msg: 'Этот лот уже купили или сняли', a: accView(a, uid, now) }); return; }
    if (l.u === uid) { out({ ok: 0, msg: 'Это твой лот' }); return; }
    if (a.adm || l.s in a.s) { out({ ok: 0, msg: 'Такой скин у тебя уже есть' }); return; }
    if ((m.p | 0) && (m.p | 0) !== l.p) { out({ ok: 0, msg: 'Цена изменилась', a: accView(a, uid, now) }); return; }
    if (a.g < l.p) { out({ ok: 0, msg: 'Не хватает голды', a: accView(a, uid, now) }); return; }
    const seller = accs[l.u], got = Math.max(0, Math.floor(l.p * (1 - MK_FEE)));
    a.g -= l.p; a.s[l.s] = 1; market.lots.delete(l.id);
    market.hist.push({ s: l.s, p: l.p, at: now }); if (market.hist.length > 300) market.hist.splice(0, market.hist.length - 300);
    accLog(a, 'купил ' + skinName(l.s) + ' за ' + l.p + ' у ' + l.sid);
    if (seller) { seller.g += got; accLog(seller, 'продал ' + skinName(l.s) + ' за ' + l.p + ' (тебе ' + got + ') игроку ' + a.id); accNote(seller, { k: 'sold', s: l.s, p: l.p, g: got }); }
    accSave(); mkSave(); log('рынок:', a.id, 'купил', l.s, 'за', l.p, 'у', l.sid);
    out({ ok: 1, s: l.s, p: l.p, a: accView(a, uid, now) }); return;
  }
  if (m.op === 'cancel') {
    const l = market.lots.get(m.lot | 0); if (!l || l.u !== uid) { out({ ok: 0, msg: 'Лот уже продан или снят', a: accView(a, uid, now) }); return; }
    mkReturn(l, 'сам', now); out({ ok: 1, s: l.s, a: accView(a, uid, now) }); return;
  }
  out({ ok: 0, msg: 'Обнови игру' });
}

// ---- лобби: своя игра для турнира или для своих. Команды до 5 на 5, карта, режим, до скольки побед ----
// Лобби бывает открытым (видно всем в списке) и закрытым (нужен пароль); глава может закрыть вход совсем.
// Пока игроки в лобби, у каждой игры открыто соединение: изменения приходят сразу. Глава жмёт «Начать»: сервер
// открывает комнату только для этих игроков, каждый со своей стороной, а после матча все возвращаются в лобби.
const LB_MAX = 150, LB_SPEC = 10;          // (3.6) третья колонка лобби: зрители (до десяти), они смотрят матч
const lobbies = new Map();
function lbKey(uid) { return crypto.createHash('sha256').update('lb:' + uid).digest('hex').slice(0, 10); }
function lbPass(p) { const s = String(p == null ? '' : p).trim().slice(0, 24); return s ? crypto.createHash('sha256').update('lbp:' + s).digest('hex') : ''; }
function newLbCode() { for (;;) { const b = crypto.randomBytes(5); let s = ''; for (let i = 0; i < 5; i++) s += CODE_ABC[b[i] & 31]; if (!lobbies.has(s)) return s; } }
function lbClean(L, m) {
  L.mode = m.mode === 'tdm' ? 'tdm' : 'bomb';
  const maps = L.mode === 'bomb' ? BOMB_MAPS : ANY_MAPS; if (maps.indexOf(m.map) >= 0) L.map = m.map; else if (maps.indexOf(L.map) < 0) L.map = maps[0];
  L.size = Math.floor(num(m.size, 1, 5, L.size || 5)); L.need = Math.floor(num(m.need, 2, 16, L.need || 8)); L.kills = Math.floor(num(m.kills, 10, 150, L.kills || 50));
  const nm = String(m.name == null ? '' : m.name).replace(/[\u0000-\u001f\u007f<>&"'`\\]/g, '').replace(/\s+/g, ' ').trim().slice(0, 28); if (nm) L.name = nm;
}
function lbTeam(L, side) { let n = 0; L.mem.forEach(q => { if (q.side === side) n++; }); return n; }
function lbView(L, uid) {
  const R = L.state === 'live' ? rooms.get(L.room) : null, inR = new Set(), wR = new Set();
  if (R) { R.players.forEach(p => { if (p.uid) inR.add(p.uid); }); if (R.watch) R.watch.forEach(c => { if (c.wu) wR.add(c.wu); }); }
  const mem = []; L.mem.forEach(q => mem.push([q.k, q.n, q.side, q.ready ? 1 : 0, q.c ? 1 : 0, q.cl ? [q.cl.t, q.cl.c] : null, q.r | 0, q.id | 0, inR.has(q.uid) ? 1 : (wR.has(q.uid) ? 2 : 0)]));
  return { code: L.code, name: L.name, host: lbKey(L.host), me: uid ? lbKey(uid) : '', mode: L.mode, map: L.map, size: L.size, need: L.need, kills: L.kills, closed: L.pass ? 1 : 0, locked: L.locked ? 1 : 0,
    state: L.state, room: L.room, mem: mem, chat: L.chat.slice(-30), last: L.last || null, nowatch: L.nowatch ? 1 : 0, watch: R && R.watch ? R.watch.size : 0, spec: LB_SPEC };
}
function lbPush(L) { const now = Date.now(); L.mem.forEach(q => { if (q.c && !q.c.dead) send(q.c, { t: 'lb', ev: 'state', l: lbView(L, q.uid), iv: invOf(q.uid, now) }); }); }
function lbListView() {
  const l = []; lobbies.forEach(L => { let n = 0; L.mem.forEach(q => { if (q.side !== 'spec') n++; }); const h = L.mem.get(L.host); l.push([L.code, L.name, L.mode, L.map, L.size, n, L.pass ? 1 : 0, L.locked ? 1 : 0, L.state, h ? h.n : '', L.need, L.kills]); });
  l.sort((a, b) => (a[8] === 'wait' ? 0 : 1) - (b[8] === 'wait' ? 0 : 1) || b[5] - a[5]); return l.slice(0, 80);
}
function lbLeave(L, uid, why) {
  const q = L.mem.get(uid); if (!q) return;
  L.mem.delete(uid); if (q.c && q.c.lb === L.code) { q.c.lb = ''; if (why) send(q.c, { t: 'lb', ev: why }); }
  if (!L.mem.size) { lobbies.delete(L.code); log('лобби', L.code, 'закрыто: никого не осталось'); return; }
  if (L.host === uid) { let best = null; L.mem.forEach(x => { if (!best || (x.c && !best.c) || ((!!x.c === !!best.c) && x.at0 < best.at0)) best = x; }); L.host = best.uid; L.chat.push(['', best.n + ' теперь глава лобби', Date.now()]); }
  lbPush(L);
}
function lbClose(L, why) { L.mem.forEach(q => { if (q.c && q.c.lb === L.code) { q.c.lb = ''; send(q.c, { t: 'lb', ev: 'closed', why: why || '' }); } }); lobbies.delete(L.code); }
function lbOf(c) { const L = c.lb ? lobbies.get(c.lb) : null; return L && c.lbu && L.mem.has(c.lbu) ? L : null; }
function lbAttach(L, c, uid, name, now) {
  for (const o of lobbies.values()) if (o !== L && o.mem.has(uid)) lbLeave(o, uid, '');       // одно лобби на игрока
  let q = L.mem.get(uid);
  if (!q) {
    let side = 'spec'; for (const s of ['ct', 't']) if (lbTeam(L, s) < L.size) { if (side === 'spec' || lbTeam(L, s) < lbTeam(L, side)) side = s; }
    q = { uid: uid, k: lbKey(uid), n: cleanName(name) || 'Игрок', side: side, ready: false, c: null, at: now, at0: now, cl: clanTagOf(uid), r: ratings[uid] ? ratings[uid].r : 1000, id: accs[uid] ? accs[uid].id : 0 };
    L.mem.set(uid, q); L.chat.push(['', q.n + ' зашёл в лобби', now]); if (L.chat.length > 60) L.chat.splice(0, L.chat.length - 60);
  }
  const nm = cleanName(name); if (nm) q.n = nm;
  if (q.c && q.c !== c && q.c.lb === L.code) q.c.lb = '';
  q.cv = c.cv | 0;
  q.c = c; q.at = now; c.lb = L.code; c.lbu = uid;
  return q;
}
function onLobby(c, m, now) {
  const uid = typeof m.uid === 'string' && UID_RE.test(m.uid) ? m.uid : '', out = o => send(c, Object.assign({ t: 'lb' }, o));
  const no = msg => out({ ev: 'no', op: String(m.op || ''), msg: msg });
  c.at = now; if (m.cv) c.cv = m.cv | 0; if (uid) c.lbw = uid;          // (3.6) кому слать приглашения по этому соединению
  if (m.op === 'ping') { const L = lbOf(c); if (L) { const q = L.mem.get(c.lbu); if (q) q.at = now; } return; }
  if (m.op === 'list') { out({ ev: 'list', l: lbListView() }); return; }
  if (!uid) { no('Обнови игру'); return; }
  if (banned(uid, now)) { const a = accs[uid]; no('Доступ к онлайну закрыт' + (a.bw ? ': ' + a.bw : '')); return; }
  if (m.op === 'make') {
    if (lobbies.size >= LB_MAX) { no('Слишком много лобби на сервере, попробуй позже'); return; }
    if (now - (c.lbMade || 0) < 3000) { no('Подожди немного'); return; }
    c.lbMade = now;
    const L = { code: newLbCode(), name: (cleanName(m.n) || 'Игрок') + ': лобби', host: uid, pass: lbPass(m.pass), locked: false, mode: 'bomb', map: 'oasis', size: 5, need: 8, kills: 50,
      state: 'wait', room: '', mem: new Map(), chat: [], made: now, seq: 0, last: null };
    lbClean(L, m); lobbies.set(L.code, L);
    lbAttach(L, c, uid, m.n, now); L.chat.length = 0; L.chat.push(['', 'Лобби создано. Код: ' + L.code, now]);
    log('лобби', L.code, 'создал', cleanName(m.n), L.pass ? '(закрытое)' : '');
    lbPush(L); return;
  }
  if (m.op === 'join' || m.op === 'back') {
    const code = String(m.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8), L = lobbies.get(code);
    if (!L) { no(m.op === 'back' ? 'Лобби уже закрыто' : 'Лобби с таким кодом нет'); return; }
    if (!L.mem.has(uid)) {
      if (m.op === 'back') { no('Тебя уже нет в этом лобби'); return; }
      const inv = L.inv && L.inv.get(uid) > now;          // (3.6) друг позвал: без пароля и при закрытом входе
      if (L.locked && !inv) { no('Глава закрыл вход в это лобби'); return; }
      if (L.pass && !inv && lbPass(m.pass) !== L.pass) { no(m.pass ? 'Неверный пароль' : 'Это закрытое лобби: нужен пароль'); return; }
      if (L.mem.size >= L.size * 2 + LB_SPEC) { no('В лобби нет мест'); return; }
      if (inv) L.inv.delete(uid);
    }
    lbAttach(L, c, uid, m.n, now); lbPush(L); return;
  }
  const L = lbOf(c); if (!L || c.lbu !== uid) { no('Ты не в лобби'); return; }
  const q = L.mem.get(uid), host = L.host === uid; q.at = now;
  switch (m.op) {
    case 'leave': lbLeave(L, uid, 'left'); return;
    case 'side': {
      const side = m.side === 't' ? 't' : (m.side === 'ct' ? 'ct' : 'spec');
      if (L.state !== 'wait') { no('Матч уже идёт'); return; }
      if (side !== 'spec' && side !== q.side && lbTeam(L, side) >= L.size) { no('В этой команде нет мест'); return; }
      if (side === 'spec' && q.side !== 'spec' && lbTeam(L, 'spec') >= LB_SPEC) { no('Среди зрителей нет мест'); return; }
      q.side = side; q.ready = false; lbPush(L); return;
    }
    case 'ready': q.ready = !!m.on; lbPush(L); return;
    case 'chat': {
      const text = cleanChat(m.text); if (!text || now - (q.chatAt || 0) < 700) return;
      q.chatAt = now; L.chat.push([q.n, text, now]); if (L.chat.length > 60) L.chat.splice(0, L.chat.length - 60); lbPush(L); return;
    }
    case 'set': {
      if (!host) { no('Это может только глава лобби'); return; }
      if (L.state !== 'wait') { no('Матч уже идёт'); return; }
      lbClean(L, m);
      if ('locked' in m) L.locked = !!m.locked;
      if ('nowatch' in m) L.nowatch = !!m.nowatch;          // (3.6) глава может запретить зрителей
      if ('pass' in m) L.pass = lbPass(m.pass);
      for (const s of ['ct', 't']) { let extra = lbTeam(L, s) - L.size; if (extra > 0) L.mem.forEach(x => { if (extra > 0 && x.side === s && x.uid !== L.host) { x.side = 'spec'; x.ready = false; extra--; } }); }
      L.mem.forEach(x => { if (x.uid !== L.host) x.ready = false; });
      lbPush(L); return;
    }
    case 'kick': case 'host': case 'move': {
      if (!host) { no('Это может только глава лобби'); return; }
      let t = null; L.mem.forEach(x => { if (x.k === m.k) t = x; }); if (!t || t.uid === uid) return;
      if (m.op === 'kick') { L.chat.push(['', t.n + ' исключён из лобби', now]); lbLeave(L, t.uid, 'kicked'); return; }
      if (m.op === 'host') { L.host = t.uid; L.chat.push(['', t.n + ' теперь глава лобби', now]); lbPush(L); return; }
      const side = m.side === 't' ? 't' : (m.side === 'ct' ? 'ct' : 'spec');
      if (L.state === 'wait' && (side === 'spec' ? lbTeam(L, 'spec') < LB_SPEC : lbTeam(L, side) < L.size)) { t.side = side; t.ready = false; lbPush(L); } else no('Там нет мест');
      return;
    }
    case 'disband': if (!host) return; lbClose(L, 'Глава распустил лобби'); return;
    case 'start': {
      if (!host) { no('Начать может только глава лобби'); return; }
      if (L.state !== 'wait') { no('Матч уже идёт'); return; }
      const team = []; L.mem.forEach(x => { if (x.side !== 'spec') team.push(x); });
      if (!lbTeam(L, 'ct') || !lbTeam(L, 't')) { no('Нужен хотя бы один игрок в каждой команде'); return; }
      const off = team.filter(x => !x.c); if (off.length) { no('Не в сети: ' + off.map(x => x.n).join(', ')); return; }
      const lazy = team.filter(x => !x.ready && x.uid !== L.host); if (lazy.length) { no('Не готовы: ' + lazy.map(x => x.n).join(', ')); return; }
      if (rooms.size >= MAX_ROOMS) { no('На сервере нет свободных комнат, попробуй позже'); return; }
      const name = ('lb-' + L.code + '-' + (++L.seq)).toLowerCase();
      const room = newRoom(name, now, L.mode, L.map, false);
      room.lobby = L.code; room.allow = new Map(); room.need = L.need; room.limit = L.kills; room.size = L.size * 2; room.made = now;
      for (const x of team) room.allow.set(x.uid, x.side === 'ct' ? 0 : 1);
      L.state = 'live'; L.room = name; L.chat.push(['', 'Матч начался: ' + (L.mode === 'bomb' ? 'закладка бомбы до ' + L.need + ' побед' : 'командный бой до ' + L.kills + ' убийств'), now]);
      log('лобби', L.code, 'начало матч в комнате', name, '| игроков', team.length);
      for (const x of team) send(x.c, { t: 'lb', ev: 'go', room: name, side: x.side, mode: L.mode, map: L.map });
      if (!L.nowatch) L.mem.forEach(x => { if (x.side === 'spec' && x.c && !x.c.dead && (x.cv | 0) >= WATCH_BUILD) send(x.c, { t: 'lb', ev: 'go', room: name, side: 'spec', watch: 1, mode: L.mode, map: L.map }); });          // (3.6) зрители идут смотреть
      lbPush(L); return;
    }
  }
}
// матч лобби закончился (или в комнате никого не осталось): все снова в лобби
function lbMatchOver(room, res) {
  const L = room.lobby ? lobbies.get(room.lobby) : null; if (!L || L.room !== room.name) return;
  L.state = 'wait'; L.room = ''; L.mem.forEach(q => { q.ready = false; q.at = Date.now(); });
  if (res) { L.last = res; L.chat.push(['', 'Матч окончен: ' + res.text, Date.now()]); }
  lbPush(L);
}
setInterval(() => {
  const now = Date.now();
  lobbies.forEach(L => {
    let changed = false;
    L.mem.forEach(q => { if (q.c && q.c.dead) { q.c = null; q.at = now; changed = true; } });
    L.mem.forEach(q => { if (!q.c && now - q.at > (L.state === 'live' ? 20 * 60000 : 150000)) { lbLeave(L, q.uid, ''); changed = false; } });
    if (L.state === 'live' && !rooms.has(L.room)) lbMatchOver({ lobby: L.code, name: L.room }, null);
    if (changed && lobbies.has(L.code)) lbPush(L);
  });
  // рынок: лоты старше 14 дней возвращаются продавцам
  market.lots.forEach(l => { if (now - l.at > MK_DAYS * 864e5) mkReturn(l, 'прошло ' + MK_DAYS + ' дней', now); });
}, 5000);

// ---- объявление от админа: его видят все в главном меню ----
const ANN = { id: 0, text: '', until: 0 };

// ---- админ-панель: страница /admin на этом же сервере. Вход по админ-коду (страница сама делает из него
// отпечаток, как игра), каждое действие проверяется заново ----
function admAcc(m) { const id = m.id | 0, uid = accIds.get(id); return uid ? { uid: uid, a: accs[uid] } : null; }
function admPlayer(uid, a, now) {
  const r = ratings[uid], k = clanOf[uid] ? clans[clanOf[uid]] : null; let room = '';
  rooms.forEach(rm => rm.players.forEach(p => { if (p.uid === uid && !p.bot) room = rm.name; }));
  let lb = ''; lobbies.forEach(L => { if (L.mem.has(uid)) lb = L.code; });
  return { id: a.id, n: a.n, g: a.g, sk: Object.keys(a.s).length, kn: Object.keys(a.k).length, r: r ? r.r : 1000, rg: r ? r.g : 0, cl: k ? k.tag : '', seen: a.seen, made: a.made, ban: a.ban > now ? a.ban : 0, bw: a.bw, adm: a.adm, room: room, lb: lb, op: a.op, fr: Object.keys(a.fr).length };
}
function admOps(c, m, now, out) {
  const fail = msg => send(c, { t: 'adm', ok: 0, op: m.op, msg: msg });
  switch (m.op) {
    case 'stats': {
      const on = onlineCount(now); let inMatch = 0; const rl = [];
      rooms.forEach(r => { const h = humans(r); inMatch += h; rl.push({ room: r.name, mode: r.mode, map: r.map, ranked: r.ranked ? 1 : 0, lobby: r.lobby || '', n: h, bots: botCount(r), score: r.mode === 'bomb' ? r.wins : [r.score.ct, r.score.t],
        players: Array.from(r.players.values()).filter(p => !p.bot).map(p => ({ n: p.name, team: p.team, k: p.kills | 0, d: p.deaths | 0, id: p.uid && accs[p.uid] ? accs[p.uid].id : 0, ping: p.ping })) }); });
      out.online = on.n; out.inMatch = inMatch; out.rooms = rl; out.accounts = accIds.size; out.lots = market.lots.size; out.lobbies = lobbies.size;
      let bans = 0; for (const u in accs) if (accs[u].ban > now) bans++; out.bans = bans; out.ann = ANN.until > now ? { text: ANN.text, until: ANN.until } : null;
      out.uptime = Math.round(process.uptime()); out.cat = CAT ? (CAT.skins.length + ' скинов, ' + CAT.cases.length + ' кейса') : ''; break;
    }
    case 'find': {
      const q = String(m.q == null ? '' : m.q).trim().toLowerCase().slice(0, 20), list = [];
      for (const u in accs) {
        const a = accs[u];
        if (q && String(a.id).indexOf(q) !== 0 && a.n.toLowerCase().indexOf(q) < 0) continue;
        list.push(admPlayer(u, a, now));
      }
      list.sort((x, y) => (y.seen || 0) - (x.seen || 0)); out.list = list.slice(0, 60); out.total = list.length; break;
    }
    case 'acc': {
      const f = admAcc(m); if (!f) { fail('Игрока с таким ID нет'); return false; }
      out.p = admPlayer(f.uid, f.a, now); out.p.s = f.a.s; out.p.k = Object.keys(f.a.k); out.p.log = f.a.log.slice(-40); out.p.nt = f.a.nt.length;
      out.p.frl = Object.keys(f.a.fr).slice(0, 100).map(u => accs[u] ? [accs[u].id, accs[u].n] : null).filter(Boolean);          // (3.6) друзья игрока
      const lots = []; market.lots.forEach(l => { if (l.u === f.uid) lots.push([l.id, l.s, l.p, l.at]); }); out.p.lots = lots; break;
    }
    case 'give': case 'take': {
      const f = admAcc(m); if (!f) { fail('Игрока с таким ID нет'); return false; }
      const a = f.a, give = m.op === 'give', note = String(m.note == null ? '' : m.note).replace(/[\u0000-\u001f\u007f<>]/g, ' ').trim().slice(0, 100);
      if (m.what === 'gold') {
        const n = Math.floor(num(m.v, 1, 10000000, 0)); if (!n) { fail('Сколько голды?'); return false; }
        if (give) a.g += n; else a.g = Math.max(0, a.g - n);
        accLog(a, (give ? 'админ дал ' : 'админ забрал ') + n + ' голды' + (note ? ': ' + note : '')); if (give) accNote(a, { k: 'gift', g: n, t: note });
      } else if (m.what === 'skin') {
        const s = String(m.v || ''); if (!CSKIN[s]) { fail('Такого скина нет'); return false; }
        if (give) { a.s[s] = 1; accNote(a, { k: 'gift', s: s, t: note }); } else delete a.s[s];
        accLog(a, (give ? 'админ дал ' : 'админ забрал ') + skinName(s) + (note ? ': ' + note : ''));
      } else if (m.what === 'knife') {
        const k = String(m.v || ''); if (!CKNIFE[k] || CKNIFE[k].std) { fail('Такого ножа нет'); return false; }
        if (give) { a.k[k] = 1; accNote(a, { k: 'gift', kn: k, t: note }); } else delete a.k[k];
        accLog(a, (give ? 'админ дал нож ' : 'админ забрал нож ') + CKNIFE[k].n);
      } else if (m.what === 'allskins' && give) {
        let n = 0; for (const s of CAT.skins) if (!(s.id in a.s)) { a.s[s.id] = 1; n++; }
        accNote(a, { k: 'gift', all: n, t: note }); accLog(a, 'админ дал все скины (+' + n + ')');
      } else if (m.what === 'case' && give) {
        const cs = CCASE[m.v]; if (!cs) { fail('Такого кейса нет'); return false; }
        let n = 0; for (const s of cs.items) if (!(s in a.s)) { a.s[s] = 1; n++; }
        accNote(a, { k: 'gift', cs: cs.id, all: n, t: note }); accLog(a, 'админ дал все скины кейса «' + cs.n + '» (+' + n + ')');
      } else if (m.what === 'msg' && give) {
        if (!note) { fail('Напиши сообщение'); return false; }
        accNote(a, { k: 'msg', t: note }); accLog(a, 'сообщение от админа: ' + note);
      } else { fail('Что выдать?'); return false; }
      accSave(); out.p = admPlayer(f.uid, a, now); out.p.s = a.s; out.p.k = Object.keys(a.k); out.p.log = a.log.slice(-40);
      log('админ:', m.op, m.what, m.v || '', '| игрок', a.id); break;
    }
    case 'ban': case 'unban': {
      const f = admAcc(m); if (!f) { fail('Игрока с таким ID нет'); return false; }
      const a = f.a;
      if (m.op === 'ban') {
        const mins = Math.floor(num(m.mins, 0, 5256000, 0)); a.ban = mins ? now + mins * 60000 : now + 100 * 365 * 864e5; a.bw = String(m.why == null ? '' : m.why).replace(/[\u0000-\u001f\u007f<>]/g, ' ').trim().slice(0, 100);
        accLog(a, 'бан ' + (mins ? 'на ' + mins + ' мин' : 'навсегда') + (a.bw ? ': ' + a.bw : ''));
        rooms.forEach(r => r.players.forEach(p => { if (p.uid === f.uid && p.c) refuse(p.c, 'ban'); }));
        lobbies.forEach(L => { if (L.mem.has(f.uid)) lbLeave(L, f.uid, 'kicked'); });
      } else { a.ban = 0; a.bw = ''; accLog(a, 'бан снят'); }
      accSave(); out.p = admPlayer(f.uid, a, now); break;
    }
    case 'kick': {
      const f = admAcc(m); if (!f) { fail('Игрока с таким ID нет'); return false; }
      let n = 0; rooms.forEach(r => r.players.forEach(p => { if (p.uid === f.uid && p.c) { refuse(p.c, 'kick'); n++; } }));
      out.n = n; break;
    }
    case 'rate': {
      const f = admAcc(m); if (!f) { fail('Игрока с таким ID нет'); return false; }
      const r = rating(f.uid, f.a.n), v = Math.floor(num(m.r, 0, 9999, -1)); if (v < 0) { fail('Рейтинг от 0 до 9999'); return false; }
      r.r = v; rateDirty = true; saveRatings(); accLog(f.a, 'админ поставил рейтинг ' + v); accSave(); out.p = admPlayer(f.uid, f.a, now); break;
    }
    case 'mk': {
      const q = String(m.q == null ? '' : m.q).trim().toLowerCase(), list = [];
      market.lots.forEach(l => { if (!q || l.s.indexOf(q) >= 0 || skinName(l.s).toLowerCase().indexOf(q) >= 0 || String(l.sid) === q) list.push([l.id, l.s, l.p, l.sid, l.n, l.at]); });
      list.sort((x, y) => y[5] - x[5]); out.lots = list.slice(0, 200); out.total = list.length; out.hist = market.hist.slice(-40).reverse(); break;
    }
    case 'mkdel': {
      const l = market.lots.get(m.lot | 0); if (!l) { fail('Лота уже нет'); return false; }
      mkReturn(l, 'убрал админ', now); out.lot = l.id; break;
    }
    case 'lbs': {
      const list = []; lobbies.forEach(L => list.push(lbView(L, ''))); out.lobbies = list; break;
    }
    case 'lbclose': {
      const L = lobbies.get(String(m.code || '').toUpperCase()); if (!L) { fail('Лобби уже нет'); return false; }
      lbClose(L, 'Лобби закрыл администратор'); break;
    }
    case 'say': {
      const text = String(m.text == null ? '' : m.text).replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 160), h = Math.floor(num(m.hours, 0, 720, 24));
      if (!text || !h) { ANN.until = 0; ANN.text = ''; } else { ANN.id++; ANN.text = text; ANN.until = now + h * 3600000; }
      log('объявление:', text || '(снято)'); out.ann = ANN.until > now ? { text: ANN.text, until: ANN.until } : null; break;
    }
    default: return true;          // остальное: коды голды (как раньше)
  }
  send(c, out); return false;
}

// ===================================================================================================
// (3.6) Друзья по ID и зрители
// ===================================================================================================

// ---- друзья: хранятся в аккаунтах. fr — друзья, fi — заявки этому игроку, fo — его заявки (uid → когда) ----
// Другим играм uid не показывается никогда: друг виден по ID аккаунта (6 цифр), имени и тому, где он сейчас.
const FR_MAX = 100, FR_REQ = 50, INV_MS = 120000, FR_ON_MS = 75000;
function accTimes(v) { const o = Object.create(null); if (v && typeof v === 'object') for (const k of Object.keys(v)) if (UID_RE.test(k) && +v[k] > 0) o[k] = +v[k]; return o; }
function frTrim(o, max) { const k = Object.keys(o); if (k.length <= max) return; k.sort((a, b) => o[a] - o[b]); for (const x of k.slice(0, k.length - max)) delete o[x]; }
function frLink(u1, u2, now) {
  const a = accs[u1], b = accs[u2]; if (!a || !b) return;
  a.fr[u2] = now; b.fr[u1] = now; delete a.fi[u2]; delete a.fo[u2]; delete b.fi[u1]; delete b.fo[u1];
  accLog(a, 'друг: ' + b.n + ' (ID ' + b.id + ')'); accLog(b, 'друг: ' + a.n + ' (ID ' + a.id + ')'); accSave();
}
// где сейчас каждый: в бою (3), смотрит матч (4), в лобби (2). Один проход по комнатам и лобби на весь список
function whereIndex() {
  const at = new Map();
  rooms.forEach(r => {
    r.players.forEach(p => { if (p.uid && !p.bot) at.set(p.uid, { k: 3, r: r }); });
    if (r.watch) r.watch.forEach(c => { if (c.wu && !at.has(c.wu)) at.set(c.wu, { k: 4, r: r }); });
  });
  lobbies.forEach(L => L.mem.forEach(q => { if (q.c && !at.has(q.uid)) at.set(q.uid, { k: 2, L: L }); }));
  return at;
}
function frOnline(uid, at, now) { const o = accs[uid]; return !!o && (now - o.seen < FR_ON_MS || at.has(uid)); }
// строка друга: [ID, имя, где (0 не в сети, 1 в меню, 2 в лобби, 3 в бою, 4 смотрит матч), бой [режим, карта, счёт, счёт] или null,
// сколько секунд назад был в сети, комната (можно зайти), можно смотреть, код лобби, название лобби, лобби открытое, рейтинг, тег клана,
// комната, которую можно смотреть]
function frRow(uid, at, now) {
  const o = accs[uid]; if (!o) return null;
  const w = at.get(uid), r = ratings[uid];
  let st = now - o.seen < FR_ON_MS ? 1 : 0, fight = null, join = '', watch = 0, L = null;
  if (w && w.r) {
    const R = w.r; st = w.k;
    const sc = R.mode === 'bomb' ? R.wins : [R.score.ct, R.score.t];
    fight = [R.ranked ? 'ranked' : R.mode, R.map, sc[0] | 0, sc[1] | 0];
    if (w.k === 3 && !R.ranked && joinable(R)) join = R.name;
    if (!R.ranked && !R.lobby) watch = 1;
    if (R.lobby) L = lobbies.get(R.lobby) || null;
  } else if (w && w.L) { st = 2; L = w.L; }
  return [o.id, o.n, st, fight, st ? 0 : Math.round((now - o.seen) / 1000), join, watch, L ? L.code : '', L ? L.name : '', L && !L.pass && !L.locked ? 1 : 0, r ? r.r : 1000, clanTagOf(uid), watch && w ? w.r.name : ''];
}
// приглашения в пати и в лобби: живут две минуты в памяти сервера, игра получает их с ответом меню, со списком друзей и в лобби
const invites = new Map(); let invSeq = 0;
function invOf(uid, now) {
  const l = invites.get(uid); if (!l) return [];
  const left = l.filter(v => now - v.at < INV_MS); if (left.length) invites.set(uid, left); else invites.delete(uid);
  return left.map(v => [v.i, v.k, v.code, v.name, v.from, v.fn, Math.max(1, Math.round((INV_MS - (now - v.at)) / 1000))]);
}
function invPut(uid, v, now) {
  v.i = ++invSeq; v.at = now;
  const l = (invites.get(uid) || []).filter(x => now - x.at < INV_MS && !(x.from === v.from && x.k === v.k)); l.push(v); if (l.length > 6) l.splice(0, l.length - 6);
  invites.set(uid, l);
  // у кого открыты лобби (список или своё лобби), получает приглашение сразу, по этому соединению
  const iv = invOf(uid, now); conns.forEach(c => { if (!c.dead && c.lbw === uid) send(c, { t: 'lb', ev: 'inv', iv: iv }); });
}
setInterval(() => { const now = Date.now(); invites.forEach((l, u) => { if (!l.some(v => now - v.at < INV_MS)) invites.delete(u); }); }, 60000);
// для главного меню: сколько заявок ждёт, сколько друзей в сети, приглашения
function frBrief(uid, now) {
  const a = uid && accs[uid]; if (!a) return null;
  const fk = Object.keys(a.fr); let on = 0;
  if (fk.length) { const at = whereIndex(); for (const f of fk) if (frOnline(f, at, now)) on++; }          // (без друзей обходить комнаты не нужно)
  return { fq: Object.keys(a.fi).length, fon: on, fn: fk.length, iv: invOf(uid, now) };
}
function frList(uid, a, now) {
  const at = whereIndex(), fr = [], fi = [], fo = [];
  for (const f of Object.keys(a.fr)) { const row = frRow(f, at, now); if (row) fr.push(row); else delete a.fr[f]; }
  for (const f of Object.keys(a.fi)) { const o = accs[f]; if (o) fi.push([o.id, o.n, Math.round((now - a.fi[f]) / 1000), ratings[f] ? ratings[f].r : 1000]); else delete a.fi[f]; }
  for (const f of Object.keys(a.fo)) { const o = accs[f]; if (o) fo.push([o.id, o.n, Math.round((now - a.fo[f]) / 1000)]); else delete a.fo[f]; }
  fi.sort((x, y) => x[2] - y[2]); fo.sort((x, y) => x[2] - y[2]);
  return { me: a.id, fr: fr, fi: fi, fo: fo, iv: invOf(uid, now), max: FR_MAX };
}
// игра 3.6: список друзей, заявка по ID, принять, отказать, отменить свою, удалить друга, позвать в пати или в лобби
function onFriends(c, m, now) {
  const uid = typeof m.uid === 'string' && UID_RE.test(m.uid) ? m.uid : '', out = o => send(c, Object.assign({ t: 'fr', op: String(m.op || '') }, o));
  const no = msg => out({ ok: 0, msg: msg });
  c.at = now;
  if (!uid) { no('Обнови игру'); return; }
  const a = accs[uid]; if (!a) { no('Аккаунт ещё не создан: открой меню игры с интернетом'); return; }
  if (banned(uid, now)) { no('Доступ к онлайну закрыт' + (a.bw ? ': ' + a.bw : '')); return; }
  a.seen = now; const nm = cleanName(m.n); if (m.n && nm) a.n = nm;
  const id = Math.floor(+m.id || 0), ouid = id >= 100000 ? accIds.get(id) || '' : '', o = ouid ? accs[ouid] : null;
  let msg = '';
  switch (m.op) {
    case 'list': break;
    case 'add': {
      if (now - (c.frAt || 0) < 1200) { no('Подожди секунду'); return; }
      c.frAt = now;
      if (!o) { no(id ? 'Игрока с ID ' + id + ' нет' : 'Введи ID друга: 6 цифр'); return; }
      if (ouid === uid) { no('Это твой собственный ID'); return; }
      if (a.fr[ouid]) { no(o.n + ' уже у тебя в друзьях'); return; }
      if (Object.keys(a.fr).length >= FR_MAX) { no('У тебя уже ' + FR_MAX + ' друзей: больше нельзя'); return; }
      if (Object.keys(o.fr).length >= FR_MAX) { no('У игрока ' + o.n + ' уже ' + FR_MAX + ' друзей'); return; }
      if (a.fi[ouid]) { frLink(uid, ouid, now); msg = 'Теперь вы друзья с ' + o.n; break; }          // он уже звал в друзья: сразу друзья
      if (a.fo[ouid]) { no('Заявка игроку ' + o.n + ' уже отправлена: ждём ответа'); return; }
      a.fo[ouid] = now; o.fi[uid] = now; frTrim(a.fo, FR_REQ); frTrim(o.fi, FR_REQ); accSave();
      msg = 'Заявка отправлена: ' + o.n + ' увидит её в игре'; break;
    }
    case 'yes': {
      if (!o || !a.fi[ouid]) { no('Этой заявки уже нет'); return; }
      if (Object.keys(a.fr).length >= FR_MAX) { no('У тебя уже ' + FR_MAX + ' друзей: больше нельзя'); return; }
      if (Object.keys(o.fr).length >= FR_MAX) { no('У игрока ' + o.n + ' уже ' + FR_MAX + ' друзей'); return; }
      frLink(uid, ouid, now); msg = 'Теперь вы друзья с ' + o.n; break;
    }
    case 'no': if (o) { delete a.fi[ouid]; delete o.fo[uid]; accSave(); } break;
    case 'cancel': if (o) { delete a.fo[ouid]; delete o.fi[uid]; accSave(); } break;
    case 'del': if (o && a.fr[ouid]) { delete a.fr[ouid]; delete o.fr[uid]; accSave(); msg = o.n + ' больше не в друзьях'; } break;
    case 'inv': {
      if (!o || !a.fr[ouid]) { no('Позвать можно только друга'); return; }
      if (now - (c.invAt || 0) < 1500) { no('Подожди немного'); return; }
      c.invAt = now;
      const at = whereIndex();
      if (!frOnline(ouid, at, now)) { no(o.n + ' сейчас не в сети'); return; }
      if (m.kind === 'lobby') {
        let L = null; lobbies.forEach(x => { if (x.mem.has(uid)) L = x; });
        if (!L) { no('Ты не в лобби'); return; }
        if (L.mem.has(ouid)) { no(o.n + ' уже в твоём лобби'); return; }
        L.inv = L.inv || new Map(); L.inv.set(ouid, now + 10 * 60000);          // по приглашению можно войти без пароля и при закрытом входе (10 минут)
        invPut(ouid, { k: 'lobby', code: L.code, name: L.name, from: a.id, fn: a.n }, now);
        msg = o.n + ' получит приглашение в лобби';
      } else {
        const code = String(m.code || '').toUpperCase(); if (!/^[A-Z0-9]{5}$/.test(code)) { no('Обнови игру'); return; }
        invPut(ouid, { k: 'party', code: code, name: '', from: a.id, fn: a.n }, now);
        msg = o.n + ' получит приглашение в пати';
      }
      break;
    }
    default: no('Обнови игру'); return;
  }
  out(Object.assign({ ok: 1, msg: msg }, frList(uid, a, now)));
}

// ---- зрители: смотрят матч, не играя. Их нет среди игроков комнаты: им приходит всё, что видят все (кроме чата команды),
// а сами они шлют только пинг. Матч лобби смотрят те, кто в лобби стоит в «Зрителях»; обычный бой — друзья тех, кто в нём;
// рейтинговый не смотрит никто ----
const WATCH_MAX = 12, WATCH_BUILD = 36, WATCH_IDLE = 30000;          // (зритель шлёт пинг раз в 3 секунды; молчит полминуты — ушёл)
function canWatch(room, uid) {
  if (!uid || room.ranked) return false;
  if (room.lobby) { const L = lobbies.get(room.lobby); return !!(L && L.mem.has(uid) && !L.nowatch && !(room.allow && room.allow.has(uid))); }
  const a = accs[uid]; if (!a) return false;
  let ok = false; room.players.forEach(p => { if (p.uid && p.uid !== uid && a.fr[p.uid]) ok = true; }); return ok;
}
function roomState(room, now) {
  const bombRoom = room.mode === 'bomb', b = room.bomb, drops = [], list = [];
  room.players.forEach(q => list.push(pub(q)));
  room.drops.forEach(d => { if (now - d.at < dropLife(room) - 2000) drops.push(dropMsg(d)); });
  const pleft = !bombRoom ? 0 : (room.phase === 'live' ? (b.state === 'planted' ? FUSE_MS - (now - b.at) : ROUND_MS - (now - room.liveAt)) : Math.max(0, room.phaseEnd - now));
  return { v: VERSION, room: room.name, limit: room.limit || KILL_LIMIT, lobby: room.lobby || '', size: room.size, state: room.state, left: Math.max(0, room.endsAt - now), now: now, s: [room.score.ct, room.score.t], players: list,
    mode: room.mode, map: room.map, ranked: room.ranked ? 1 : 0, need: room.need || NEED, wins: room.wins, side: room.side, round: room.round, phase: room.phase, pleft: Math.max(0, pleft),
    bomb: bombRoom ? { state: b.state, carrier: b.carrier, x: b.x, y: b.y, z: b.z } : null, host: room.host ? room.host.id : 0, bots: botRoom(room) ? BOT_TEAM : 0, mapv: MAP_VER, drops: drops, eco: bombRoom ? 1 : 0, buy: BUY_MS };
}
function onWatch(c, m, now, uid) {
  if ((m.cv | 0) < WATCH_BUILD) { refuse(c, 'version'); return; }
  const room = rooms.get(cleanRoom(String(m.room == null ? '' : m.room)));
  if (!room) { refuse(c, 'gone'); return; }
  if (!canWatch(room, uid)) { refuse(c, 'nowatch'); return; }
  if (!room.watch) room.watch = new Set();
  if (room.watch.size >= WATCH_MAX) { refuse(c, 'watchfull'); return; }
  c.w = room; c.wu = uid; c.at = now; room.watch.add(c);
  const name = cleanName(m.name);
  send(c, Object.assign(roomState(room, now), { t: 'welcome', id: 0, watch: 1, name: name, team: 'spec', rating: ratings[uid] ? ratings[uid].r : 1000, mate: 0, adm: 0, admchk: 0, kit: null }));
  log('зритель:', name, '| комната', room.name, '| зрителей', room.watch.size);
  if (room.lobby) { const L = lobbies.get(room.lobby); if (L) lbPush(L); }
}
// комната закрылась: зрителям сказать, что смотреть больше нечего
function watchGone(room) {
  if (!room.watch) return;
  room.watch.forEach(c => { c.w = null; send(c, { t: 'gone' }); setTimeout(() => drop(c, 'матч закрыт'), 400); });
  room.watch.clear();
}
// здоровье и броня бойцов: зрителям всех, погибшим людям — своей команды (они смотрят глазами своих). Раз в 0.3 с
function sendHp(room) {
  const all = [], team = { ct: [], t: [] }; let dead = false;
  room.players.forEach(p => { if (p.alive) { const e = [p.id, Math.max(0, Math.round(p.hp)), Math.round(p.armor)]; all.push(e[0], e[1], e[2]); if (team[p.team]) team[p.team].push(e[0], e[1], e[2]); } else if (!p.bot && p.c && (p.cv | 0) >= WATCH_BUILD) dead = true; });
  if (!all.length) return;
  if (room.watch && room.watch.size) { const buf = frame(JSON.stringify({ t: 'hp', l: all })); room.watch.forEach(c => sendRaw(c, buf)); }
  if (dead) room.players.forEach(p => { if (!p.alive && !p.bot && p.c && (p.cv | 0) >= WATCH_BUILD && team[p.team] && team[p.team].length) send(p.c, { t: 'hp', l: team[p.team] }); });
}

// ---- сеть -------------------------------------------------------------------------------------
const server = http.createServer((req, res) => {
  let players = 0; rooms.forEach(r => { players += humans(r); });
  const now = Date.now(), url = String(req.url || '/').split('?'), q = /(?:^|&)p=([a-z0-9]{4,16})(?:&|$)/.exec(url[1] || '');
  if (q) mark(q[1], now);
  const on = onlineCount(now);
  // (3.5) админ-панель: страница и каталог скинов для неё (вход на самой странице по админ-коду)
  if (url[0] === '/admin' || url[0] === '/admin/' || url[0] === '/admin/catalog.json') {
    const file = url[0] === '/admin/catalog.json' ? 'catalog.json' : 'admin.html';
    fs.readFile(path.join(__dirname, file), (err, buf) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Нет файла ' + file + ': обнови сервер'); return; }
      res.writeHead(200, { 'Content-Type': file === 'admin.html' ? 'text/html; charset=utf-8' : 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff' });
      res.end(buf);
    });
    return;
  }
  if (url[0] === '/status') {
    const list = []; rooms.forEach(r => list.push({ room: r.name, mode: r.mode, map: r.map, ranked: r.ranked, players: humans(r), bots: botCount(r), score: r.mode === 'bomb' ? r.wins : [r.score.ct, r.score.t] }));
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify({ ok: true, name: 'brick-strike', version: VERSION, online: on.n, players: players, rooms: list, uptime: Math.round(process.uptime()) }));
    return;
  }
  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end('Brick Strike: сервер работает.\nСейчас онлайн: ' + on.n + ' (в матчах ' + players + '), комнат: ' + rooms.size + '\nВ игре укажи адрес этого сервера и порт ' + PORT + '.\n');
});
server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket' || conns.size >= MAX_CONN) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true); socket.setKeepAlive(true, 30000);
  const c = { s: socket, buf: null, frag: null, fragLen: 0, fragText: true, p: null, room: null, dead: false, at: Date.now(), rl: 0, rlAt: Date.now(), ip: String(socket.remoteAddress || '') };
  conns.add(c);
  socket.on('data', chunk => { try { onData(c, chunk); } catch (e) { log('ошибка в сообщении:', e && e.message); drop(c, 'error'); } });
  socket.on('close', () => drop(c, ''));
  socket.on('error', () => drop(c, ''));
});
server.on('clientError', (err, socket) => { try { socket.destroy(); } catch (e) { /* закрыт */ } });
process.on('uncaughtException', e => log('необработанная ошибка:', e && e.stack || e));
process.on('SIGTERM', () => { saveRatings(); accFlush(); mkFlushNow(); process.exit(0); });
process.on('SIGINT', () => { saveRatings(); accFlush(); mkFlushNow(); process.exit(0); });
server.listen(PORT, '0.0.0.0', () => log('Brick Strike 3.6: сервер слушает порт ' + PORT + ' | командный бой до ' + KILL_LIMIT + ' убийств или ' + MATCH_MS / 60000 + ' мин' + (BOT_TEAM ? ', боты добирают команды до ' + BOT_TEAM : ', без ботов') + ' | бомба до ' + NEED + ' побед, раунды с деньгами как в CS, рейтинг строго 2 на 2 и только между игроками | оружие по сторонам | пати по коду | в комнате до ' + ROOM_SIZE + ' игроков | рейтинг: ' + RATE_FILE));
