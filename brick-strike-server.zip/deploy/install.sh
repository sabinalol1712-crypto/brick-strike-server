#!/bin/bash
# Установка сервера Brick Strike на сервер Hetzner (Ubuntu), рядом с другими играми (Prodigy Strike занимает 8080,
# ETN FACEIT 8090, Brick Strike встаёт на 3100). Запускается один раз, в консоли сервера под root:
#   git clone https://github.com/sabinalol1712-crypto/brick-strike-server.git /opt/brick-strike && cd /opt/brick-strike && ( [ -f deploy/install.sh ] || python3 -m zipfile -e brick-strike-server.zip . ) && bash deploy/install.sh
# Дальше сервер сам берёт новые версии с GitHub каждые 3 минуты (когда в матчах никого нет): достаточно залить новый архив.
set -e
DIR=/opt/brick-strike
PORT=3100
export DEBIAN_FRONTEND=noninteractive
cd "$DIR"

echo "== пакеты"
need() { command -v "$1" >/dev/null 2>&1 || { apt-get update -y >/dev/null; apt-get install -y "$2"; }; }
need node nodejs; need git git; need python3 python3; need curl curl
NODE_MAJOR=$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)
if [ "$NODE_MAJOR" -lt 12 ]; then echo "!! Node.js слишком старый (версия $NODE_MAJOR)"; exit 1; fi

# если сервер уже запускали вручную через pm2 или по расписанию — убрать, чтобы не было двух серверов на одном порту
if command -v pm2 >/dev/null 2>&1; then pm2 delete brick-strike >/dev/null 2>&1 && pm2 save >/dev/null 2>&1 || true; fi
if crontab -l 2>/dev/null | grep -q bs-update.sh; then crontab -l 2>/dev/null | grep -v bs-update.sh | crontab - || true; fi

echo "== пользователь и папка данных (рейтинг лежит в data/ и при обновлениях не теряется)"
id brickstrike >/dev/null 2>&1 || useradd --system --home "$DIR" --shell /usr/sbin/nologin brickstrike
mkdir -p "$DIR/data"
[ -f "$DIR/ratings.json" ] && [ ! -f "$DIR/data/ratings.json" ] && mv "$DIR/ratings.json" "$DIR/data/ratings.json"
chown -R brickstrike:brickstrike "$DIR"
chmod 750 "$DIR/data"
git config --system --get-all safe.directory 2>/dev/null | grep -qx "$DIR" || git config --system --add safe.directory "$DIR"

echo "== служба игры и автообновление"
cp deploy/brick-strike.service /etc/systemd/system/brick-strike.service
cp deploy/brick-strike-update.service /etc/systemd/system/brick-strike-update.service
cp deploy/brick-strike-update.timer /etc/systemd/system/brick-strike-update.timer
systemctl daemon-reload
systemctl enable brick-strike >/dev/null 2>&1
systemctl restart brick-strike
systemctl enable --now brick-strike-update.timer >/dev/null 2>&1

# если включён файрвол — открыть порт игры
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then ufw allow $PORT/tcp; fi

IP=$(curl -fsS --max-time 3 http://169.254.169.254/hetzner/v1/metadata/public-ipv4 2>/dev/null || true)
[ -n "$IP" ] || IP=$(hostname -I | awk '{print $1}')
sleep 2
if curl -fsS --max-time 5 "http://127.0.0.1:$PORT/status" >/dev/null; then
  echo ""
  echo "== ГОТОВО: сервер Brick Strike работает. Проверка в браузере: http://$IP:$PORT"
  echo "== в файле address.txt на GitHub последней строкой должно стоять: $IP"
else
  echo "!! сервер не отвечает — смотри: journalctl -u brick-strike -n 50"
fi
