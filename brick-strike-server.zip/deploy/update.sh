#!/bin/bash
# Запускается таймером каждые 3 минуты: берёт новую версию с GitHub (архив brick-strike-server.zip или отдельные файлы).
# Перезапуск — когда в матчах никого нет (или после 30 минут ожидания). Рейтинг хранится в data/ и не теряется.
DIR=/opt/brick-strike
cd "$DIR" || exit 0
[ -d .git ] || exit 0
OLD=$(git rev-parse HEAD)
sudo -u brickstrike git fetch -q origin || exit 0
NEW=$(git rev-parse origin/HEAD 2>/dev/null || git rev-parse origin/main)
[ "$OLD" = "$NEW" ] && { rm -f /tmp/bs-pending; exit 0; }
PLAYERS=$(curl -fsS --max-time 3 http://127.0.0.1:3100/status | sed -n 's/.*"players":\([0-9]*\).*/\1/p')
[ -f /tmp/bs-pending ] || date +%s > /tmp/bs-pending
WAITED=$(( $(date +%s) - $(cat /tmp/bs-pending) ))
if [ "${PLAYERS:-0}" != "0" ] && [ "$WAITED" -lt 1800 ]; then exit 0; fi
sudo -u brickstrike git reset -q --hard "$NEW"
# сервер загружен в репозиторий одним архивом — распаковать поверх
if [ -f brick-strike-server.zip ]; then sudo -u brickstrike python3 -m zipfile -e brick-strike-server.zip . ; fi
cp deploy/brick-strike.service /etc/systemd/system/brick-strike.service
cp deploy/brick-strike-update.service /etc/systemd/system/brick-strike-update.service
cp deploy/brick-strike-update.timer /etc/systemd/system/brick-strike-update.timer
systemctl daemon-reload
systemctl restart brick-strike
rm -f /tmp/bs-pending
echo "updated $OLD -> $NEW"
